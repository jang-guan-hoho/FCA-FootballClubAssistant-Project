<template>
    <div>
      <h4>스케줄 생성</h4>
      <form @submit.prevent="createSchedule">
        <fieldset>
          <legend>스케줄 정보 입력</legend>
          <div>
            <label for="date">날짜:</label>
            <input type="date" id="date" v-model="newSchedule.date" required>
          </div>
          <div>
            <label for="title">제목:</label>
            <input type="text" id="title" v-model="newSchedule.title" required>
          </div>
          <div>
            <label for="startTime">시작 시간:</label>
            <input type="time" id="startTime" v-model="startTime" required>
          </div>
          <div>
            <label for="endTime">종료 시간:</label>
            <input type="time" id="endTime" v-model="endTime" required>
          </div>
          <div>
            <label for="equipment">장비:</label>
            <input type="text" id="equipment" v-model="newSchedule.equipment">
          </div>
          <div>
            <label for="match">모집인원:</label>
            <input type="number" id="match" v-model="newSchedule.match" required>
          </div>
          <button type="submit">생성</button>
        </fieldset>
      </form>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue';
  import { useScheduleStore } from '@/stores/schedule';
  import { useRouter, useRoute } from 'vue-router';
  const accessToken = sessionStorage.getItem('accessToken')
  const router = useRouter();
  const route = useRoute();
  const sstore = useScheduleStore();
  const startTime = ref('');
  const endTime = ref('');
  const newSchedule = ref({
    date:'',
    title: '',
    time: '',
    equipment: '',
    match: 0,
    placeId: route.params.placeId // 라우터에서 placeId를 가져옴
  });
  
  const createSchedule = async () => {
    newSchedule.value.time = `${startTime.value}~${endTime.value}`;
    try {
      const response = await sstore.createSchedule(route.params.clubId,newSchedule.value);
      if (response.status === 201) {
        router.push({ name: 'clubScheduleList' });
      }
    } catch (error) {
      console.error('스케줄 생성 중 오류 발생:', error);
    }
    console.log(newSchedule.value)
  };
  </script>
  
  <style scoped>
  fieldset {
    margin-top: 20px;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
  }
  label {
    display: block;
    margin-bottom: 10px;
  }
  input[type="text"],
  input[type="datetime-local"],
  input[type="number"] {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
  }
  button {
    margin-top: 20px;
    padding: 10px 20px;
    cursor: pointer;
  }
  </style>
  
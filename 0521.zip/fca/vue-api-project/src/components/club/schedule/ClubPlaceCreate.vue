<template>
    <div>
      <h4>장소 생성</h4>
      <KakaoMap />
      <form @submit.prevent="createPlace">
        <fieldset>
          <legend>장소 정보 입력</legend>
          <div>
            <label for="placeName">장소 이름:</label>
            <input type="text" id="placeName" v-model="newPlace.name" required>
          </div>
          <div>
            <label for="address">주소:</label>
            <input type="text" id="address" v-model="newPlace.address" required>
          </div>
          <div>
            <label for="url">URL:</label>
            <input type="text" id="address" v-model="newPlace.url" required>
          </div>
          <button type="submit">생성</button>
        </fieldset>
      </form>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue';
  import { useRoute,useRouter } from 'vue-router';
  import axios from 'axios';
import KakaoMap from '@/components/common/kakao/KakaoMap.vue';
  const accessToken = sessionStorage.getItem('accessToken')
  const newPlace = ref({
    name: '',
    address: '',
    url:'',
  });
  
  const router = useRouter();
  const route = useRoute();
  
  const createPlace = async () => {
    try {
      const response = await axios.post(`http://localhost:8080/fca/club/${route.params.clubId}/place`, newPlace.value,{
        headers:{'accessToken':accessToken}
      })
      const placeId = response.data.placeId;
      console.log('장소 생성 완료, placeId:', placeId);
      // 장소 생성 후 placeId를 가지고 스케줄 생성 페이지로 이동
      router.push({ name: 'ClubScheduleCreate', params: { placeId:placeId, clubId:route.params.clubId } });
    } catch (error) {
      console.error('장소 생성 중 오류 발생:', error);
    }

  };
  </script>
  
  <style scoped>
  fieldset {
    margin-top: 20px;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
  }
  label {
    display: block;
    margin-bottom: 10px;
  }
  input[type="text"] {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
  }
  button {
    margin-top: 20px;
    padding: 10px 20px;
    cursor: pointer;
  }
  </style>
  
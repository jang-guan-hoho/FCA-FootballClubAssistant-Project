<template>
    <div>
        <h2>BoardView</h2>

        <RouterView />
    </div>
</template>

<script setup>



</script>

<style scoped></style>
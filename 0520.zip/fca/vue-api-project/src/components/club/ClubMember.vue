<template>
    <div>
      <h3>클럽 멤버 관리</h3>
      <table>
        <thead>
          <tr>
            <th>프로필</th>
            <th>이름</th>
            <th>직책</th>
            <th>마지막 일정 참가일</th>
            <th>회비 납부 여부</th>
            <th>탈퇴</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="member in clubMember" :key="member.userId">
            <td>
              <img :src="member.profile" alt="프로필 이미지" class="profile-img" />
            </td>
            <td>{{ member.name }}</td>
            <td>
              <select v-model="member.position" @change="updatePosition(member)">
                <option value="멤버">멤버</option>
                <option value="관리자">관리자</option>
              </select>
            </td>
            <td>{{ member.currentDate }}</td>
            <td>
              <button
                :class="member.feePaid ? 'paid' : 'unpaid'"
                @click="toggleFeeStatus(member)"
              >
                {{ member.feePaid ? '납부' : '미납' }}
              </button>
            </td>
            <td>
              <button @click="removeMember(member.userId)">탈퇴</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </template>
  
  <script setup>
  import { useClubStore } from '@/stores/club';
import axios from 'axios';
  import { ref, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
  
  const store = useClubStore();
  
  const clubMember = ref([]);
  const route = useRoute();
  const router = useRouter();
  onMounted(() => {
    // store.getClubMember(route.params.clubId); // 클럽 ID를 지정해 주세요.
    clubMember.value = store.clubMember;
  });
  
  const updatePosition = (member) => {
    console.log(`Updating position for ${member.name} to ${member.position}`);
    // 서버에 직책 업데이트 요청을 보냅니다.
    // axios.post('서버 URL', { userId: member.userId, position: member.position })
  };
  
  const toggleFeeStatus = (member) => {
    member.feePaid = !member.feePaid;
    console.log(`Fee status for ${member.name}: ${member.feePaid ? '납부' : '미납'}`);
    // 서버에 회비 납부 여부 업데이트 요청을 보냅니다.
    // axios.post('서버 URL', { userId: member.userId, feePaid: member.feePaid })
  };
  
  const removeMember = (userId) => {
    console.log(`Removing member with userId: ${userId}`);
    // 서버에 클럽원 탈퇴 요청을 보냅니다.
    // axios.delete(`http://localhost:8080/api-board/board/${userId}`)
    //     .then(() => {
    //         router.push({name:'ClubMember', params:{clubId:route.params.clubId}})
    //     })
    clubMember.value = clubMember.value.filter(member => member.userId !== userId);
    console.log(clubMember.value)
    router.push({name:'ClubMember', params:{clubId:route.params.clubId}})
  };

  </script>
  
  <style scoped>
  .profile-img {
    width: 50px;
    height: 50px;
    border-radius: 50%;
  }
  .paid {
    background-color: lightgreen;
  }
  .unpaid {
    background-color: lightcoral;
  }
  </style>
  
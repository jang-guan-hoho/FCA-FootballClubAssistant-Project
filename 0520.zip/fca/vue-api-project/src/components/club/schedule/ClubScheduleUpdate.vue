<template>
    <div>
      <h4>스케줄 수정</h4>
      <form @submit.prevent="updateSchedule">
        <fieldset>
          <legend>스케줄 정보 수정</legend>
          <div>
            <label for="date">날짜:</label>
            <input type="date" id="date" v-model="schedule.date" required>
          </div>
          <div>
            <label for="startTime">시작 시간:</label>
            <input type="time" id="startTime" v-model="startTime" required>
          </div>
          <div>
            <label for="endTime">종료 시간:</label>
            <input type="time" id="endTime" v-model="endTime" required>
          </div>
          <div>
            <label for="equipment">장비:</label>
            <input type="text" id="equipment" v-model="schedule.equipment" required>
          </div>
          <div>
            <label for="match">모집 인원:</label>
            <input type="number" id="match" v-model="schedule.match" required>
          </div>
          <button type="submit">수정</button>
        </fieldset>
      </form>
    </div>
  </template>
  
  <script setup>
  import { ref, onMounted } from 'vue';
  import { useRoute, useRouter } from 'vue-router';
  import axios from 'axios';
import { useScheduleStore } from '@/stores/schedule';
    const store =   useScheduleStore();
  const schedule = ref({
    date: '',
    time: '',
    equipment: '',
    match: '',
  });
  
  const startTime = ref('');
  const endTime = ref('');
  
  const router = useRouter();
  const route = useRoute();
  
  const loadScheduleDetails = async () => {
    // try {
    //   const response = await axios.get(`http://localhost:8080/api/schedule/${route.params.scheduleId}`);
    //   schedule.value = response.data;
      
    //   // 시작 시간과 종료 시간을 분리하여 초기화
    //   if (schedule.value.time) {
    //     const [start, end] = schedule.value.time.split('~');
    //     startTime.value = start.trim();
    //     endTime.value = end.trim();
    //   }
    // } catch (error) {
    //   console.error('스케줄 정보를 불러오는 중 오류 발생:', error);
    // }
    schedule.value = store.schedule;
  };
  
  const updateSchedule = async () => {
    // try {
    //   // 시작 시간과 종료 시간을 결합하여 time 필드에 저장
    //   schedule.value.time = `${startTime.value}~${endTime.value}`;
      
    //   await axios.put(`http://localhost:8080/api/schedule/${route.params.scheduleId}`, schedule.value);
    //   console.log('스케줄 수정 완료');
    //   // 스케줄 수정 후 상세 페이지로 이동
    //   router.push({ name: 'clubScheduleDetail', params: { scheduleId: route.params.scheduleId } });
    // } catch (error) {
    //   console.error('스케줄 수정 중 오류 발생:', error);
    // }

    schedule.value.time = `${startTime.value}~${endTime.value}`;
    console.log(schedule.value)
  };
  
  onMounted(() => {
    loadScheduleDetails();
  });
  </script>
  
  <style scoped>
  fieldset {
    margin-top: 20px;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
  }
  label {
    display: block;
    margin-bottom: 10px;
  }
  input[type="date"],
  input[type="time"],
  input[type="text"],
  input[type="number"] {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
  }
  button {
    margin-top: 20px;
    padding: 10px 20px;
    cursor: pointer;
  }
  </style>
  
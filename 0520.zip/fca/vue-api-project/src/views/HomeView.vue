<template>
  
  <div>
    <h2>HomeView</h2>
    
  </div>
</template>

<script setup>

</script>

<style scoped>
div{
  background-image: url('/tossVue/fca/vue-api-project/src/assets/img/background.PNG');
}
</style>

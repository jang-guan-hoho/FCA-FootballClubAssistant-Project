DROP SCHEMA IF EXISTS FCA;
CREATE SCHEMA IF NOT EXISTS FCA;
USE FCA;


CREATE TABLE `club` (
	`club_id` INT NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(200) NOT NULL,
	`max_member` INT NOT NULL COMMENT 'maximum 100',
	`content` TEXT NOT NULL COMMENT 'placehold',
	`fee` INT NOT NULL COMMENT '1000~',
	`deadline` INT NOT NULL COMMENT '1~28',
	`club_img` VARCHAR(200) NULL DEFAULT 'default_club_img',
	`logo` VARCHAR(200) NULL DEFAULT 'default_logo',
	`account` INT NOT NULL,
	`bank` VARCHAR(200) NOT NULL,
	`region` VARCHAR(200) NOT NULL,
    `money` int NULL DEFAULT 0,
	PRIMARY KEY (`club_id`)
);
CREATE TABLE `user` (
	`user_id` INT NOT NULL AUTO_INCREMENT,
	`email` VARCHAR(200) NOT NULL,
	`password` VARCHAR(200) NOT NULL,
	`name` VARCHAR(200) NOT NULL,
	`gender` BOOLEAN NOT NULL COMMENT '남 - M / 여 - F',
	`birth` DATE NOT NULL,
	`intro` TEXT NOT NULL COMMENT 'placehold',
	`profile` VARCHAR(200) NULL,
    -- `profile` VARCHAR(200) NULL DEFAULT 'default_profile',
	PRIMARY KEY (`user_id`)
);
CREATE TABLE `place` (
	`place_id` INT NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(200) NOT NULL,
	`address` VARCHAR(200) NOT NULL,
	`url` VARCHAR(200) NULL,
	PRIMARY KEY (`place_id`)
);

CREATE TABLE `schedule` (
	`schedule_id` INT NOT NULL AUTO_INCREMENT,
    `title` VARCHAR(200) NOT NULL,
	`date` DATE NOT NULL,
    `time` VARCHAR(200) NOT NULL,
	`match` INT NULL,
	`equipment` VARCHAR(200) NULL,
    `cost` INT NULL DEFAULT 0,
	`place_id` INT NOT NULL,
	`club_id` INT NOT NULL,
	PRIMARY KEY (`schedule_id`),
	FOREIGN KEY (`club_id`) REFERENCES `club`(`club_id`),
    FOREIGN KEY (`place_id`) REFERENCES `place`(`place_id`)
);



CREATE TABLE `member` (
	`member_id` INT NOT NULL AUTO_INCREMENT,
	`club_id` INT NOT NULL,
	`user_id` INT NOT NULL,
	`position` VARCHAR(200) NOT NULL,
    `current_date` DATE NULL,
	-- `billing_key` VARCHAR(255) NOT NULL,
	PRIMARY KEY (`member_id`),
	FOREIGN KEY (`club_id`) REFERENCES `club`(`club_id`),
	FOREIGN KEY (`user_id`) REFERENCES `user`(`user_id`)
);

CREATE TABLE `participant` (
	`participant_id` INT NOT NULL AUTO_INCREMENT,
	`schedule_id` INT NOT NULL,
	`user_id` INT NOT NULL,
	PRIMARY KEY (`participant_id`),
	FOREIGN KEY (`schedule_id`) REFERENCES `schedule`(`schedule_id`),
	FOREIGN KEY (`user_id`) REFERENCES `user`(`user_id`)
);


CREATE TABLE `receipt` (
	`receipt_id` INT NOT NULL AUTO_INCREMENT,
	`item` VARCHAR(200) NOT NULL,
	`price` INT NOT NULL,
	`schedule_id` INT NOT NULL,
	PRIMARY KEY (`receipt_id`),
	FOREIGN KEY (`schedule_id`) REFERENCES `schedule`(`schedule_id`)
);

CREATE TABLE `payment` (
	`payment_id` VARCHAR(200) NOT NULL,
	`pay_date` TIMESTAMP NOT NULL,
    `price` INT NOT NULL,
	`comment` VARCHAR(200) NOT NULL,
	`club_id` INT NOT NULL,
	`user_id` INT NOT NULL,
	PRIMARY KEY (`payment_id`),
	FOREIGN KEY (`club_id`) REFERENCES `club`(`club_id`),
	FOREIGN KEY (`user_id`) REFERENCES `user`(`user_id`)
);

CREATE TABLE `board` (
	`board_id` INT NOT NULL AUTO_INCREMENT,
	`title` VARCHAR(200) NOT NULL,
	`content` TEXT NOT NULL COMMENT 'placehold',
	`category` VARCHAR(200) NOT NULL COMMENT '공지 - Notice / 일반 - General',
	`date` DATE NOT NULL,
	`user_id` INT NOT NULL,
	`club_id` INT NOT NULL,
	`view_cnt` INT NULL DEFAULT 0,
	`file` VARCHAR(200) NULL,
	PRIMARY KEY (`board_id`),
	FOREIGN KEY (`user_id`) REFERENCES `user`(`user_id`),
	FOREIGN KEY (`club_id`) REFERENCES `club`(`club_id`)
);


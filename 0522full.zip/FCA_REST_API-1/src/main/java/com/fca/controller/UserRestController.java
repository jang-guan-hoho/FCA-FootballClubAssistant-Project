package com.fca.controller;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fca.annotation.AuthRequired;
import com.fca.model.dto.User;
import com.fca.model.service.UserService;
import com.fca.util.JwtUtil;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/fca")
@Tag(name = "UserRestController", description = "User CRUD")
public class UserRestController {
	
	private UserService userService;
	
	private JwtUtil jwtUtil;
	
	private ResourceLoader resLoader;
	
	@Autowired
	public UserRestController(UserService userService, JwtUtil jwtUtil, ResourceLoader resLoader) {
		this.userService = userService;
		this.jwtUtil = jwtUtil;
		this.resLoader = resLoader;
	}
	
	@Value("${jwt.refreshtoken.expiretime}")
	private int refreshTokenExpireTime;
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody User user, HttpServletResponse response) throws UnsupportedEncodingException{
		
		Map<String, Object> result = new HashMap<>();
		
		// DB에서 유저 가져오기
		User dbUser = userService.loginUser(user);
		
		// 일치하는 유저가 없다면 UNAUTHORIZED 반환.
		if(dbUser == null) {
			result.put("message", "일치하는 유저가 없습니다.");
			return new ResponseEntity<Map<String, Object>>(result, HttpStatus.UNAUTHORIZED);
		}
		
		// 있으면 Token 발급
		// AccessToken, RefreshToken 두 개를 발급해준다.
		String accessToken = jwtUtil.createAccessToken(dbUser.getUserId());
		String refreshToken = jwtUtil.createRefreshToken(dbUser.getUserId());
		
		// refreshtoken은 처음 발급할 때 -> DB에 저장.
		// INSERT INTO `refresh-token` (userId, refreshToken)  VALUE (#{userId}, #{refreshToken}) 
		
		
		// Front End와 합의사항
		//1.) accessToken, refreshToken => 본문에 둘다 보내도 되고,
		//   refreshToken: localStorage에 저장, accessToken: sessionStorage 또는 pinia store에만.
		
		//2.) accessToken만 응답 본문에 넣어서 보내고, refreshToken은 쿠키에 넣어서 보냄. => 
		//  refreshToken은 브라우저에 자동 저장
		//  accessToken만 sessionStorage 또는 pinia store에 저장.
		
		Cookie cookie = new Cookie("refreshToken", refreshToken);
		cookie.setMaxAge(refreshTokenExpireTime);
		cookie.setHttpOnly(true);
		cookie.setPath("/");
		response.addCookie(cookie);
		
		result.put("accessToken", accessToken);
		result.put("loginUser", dbUser);
		
		
		return new ResponseEntity<>(result, HttpStatus.ACCEPTED);
	}
	
	
//	@AuthRequired // 토큰이 있어야지만 접근 가능한 메서드.
//	@GetMapping("/mypage")
//	ResponseEntity<?> mypage(HttpServletRequest request) throws ParseException{
//		String accessToken = request.getHeader("accessToken");
//		int userId = jwtUtil.getUserId(accessToken);
//		
//		return new ResponseEntity<>(userId, HttpStatus.OK);
//	}
	
	@GetMapping("/refresh")
	ResponseEntity<?> refreshToken(){
		
		// accessToken의 유효기간이 얼마 안남았고
		// refreshToken은 있는 상황에만 accessToken을 재발급해주겠다.
		
		// 1. COOKIE 헤더에서 refreshToken 가져오기
		// 2. DB에 있는 refreshToken과 일치여부 확인
		//   2-1. 일치한다면 accessToken을 새걸로 만들어서 반환
		//   2-2. 그렇지 않다면 "messege" "다시 로그인하세요"
		// 3. refreshToken이 이상한 경우 => 다시 로그인하세요.
		
		
		// ex) 은행 로그인에서 로그인 연장하기 버튼을 눌렀을 때
		//     또는
		//     웹 서비스를 정상적으로 사용하고 있을 때(주기적으로 refresh 요청을 같이 날려서
		//     accessToken을 최신화해줌.
		
				
		return null;
	}
	
//////////////////////////////////////////////////////////////////////////////
	
    // 마이페이지로 이동
//    @GetMapping("/my-page")
//    public ResponseEntity<?> goMyPage(){
//        return new ResponseEntity<Void>(HttpStatus.OK);
//    }
	
	/*
	    public ResponseEntity<?> signin(@RequestPart("user") User user,
            @RequestPart(value = "file", required = false) MultipartFile file) {
        int result = uService.signUser(user, file);
        return new ResponseEntity<>(result, result == 1 ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }
    
    private int fileHandling(User user, MultipartFile file) throws IOException {
        // 파일을 저장할 폴더 지정 (자바 폴더 내에 지정)
        Resource res = resLoader.getResource("classpath:/static/resources");
//        //파일 저장할 때 이렇게 resource폴더에 하는게 좋음...
//        if(!res.getFile().exists()) {
//            res.getFile().mkdirs(); // 두 경로이므로 이겋게해야함.
//        }
        
        if (file != null && file.getSize() > 0) {
            // prefix를 포함한 전체 이름
            user.setImg(System.currentTimeMillis() + "_" + file.getOriginalFilename());
            user.setOrgImg(file.getOriginalFilename());

            // 변경된 파일 이름이 적용된 Movie MovieService를 통해 DB에 저장한다.

            file.transferTo(new File(res.getFile(), user.getImg()));
        }
        
        
//        //로컬에 저장
//        if (file != null && !file.isEmpty()) {
//            String userHome = System.getProperty("user.home");
//            String uploadDirPath = userHome + "/Desktop/createUser";
//            Path uploadPath = Paths.get(uploadDirPath);
//            if (!Files.exists(uploadPath)) {
//                Files.createDirectories(uploadPath);
//            }
//            String filename = System.currentTimeMillis() + "_" + file.getOriginalFilename();
//            file.transferTo(new File(uploadDirPath, filename));
//            user.setImg(filename); // 파일 이름을 img 필드에 설정
//            user.setOrgImg(file.getOriginalFilename());
//        }
        
        return uDao.insert(user);
    }
	 * */
	
	// 회원가입 실행
	@PostMapping("/sign-up")
	public ResponseEntity<?> doSignUp(@RequestPart("user") User user, @RequestPart(value = "profile", required = false) MultipartFile file) throws IOException{
		// 파일을 저장할 폴더 지정 (자바 폴더 내에 지정)
        Resource res = resLoader.getResource("classpath:/static/resources");
//        //파일 저장할 때 이렇게 resource폴더에 하는게 좋음...
        if(!res.getFile().exists()) {
            res.getFile().mkdirs(); // 두 경로이므로 이겋게해야함.
        }
        
        if (file != null && file.getSize() > 0) {
            // prefix를 포함한 전체 이름
            user.setProfile(System.currentTimeMillis() + "_" + file.getOriginalFilename());
            user.setOrgProfile(file.getOriginalFilename());

            file.transferTo(new File(res.getFile(), user.getProfile()));
        }
        
        
//        //로컬에 저장
//        if (file != null && !file.isEmpty()) {
//            String userHome = System.getProperty("user.home");
//            String uploadDirPath = userHome + "/Desktop/createUser";
//            Path uploadPath = Paths.get(uploadDirPath);
//            if (!Files.exists(uploadPath)) {
//                Files.createDirectories(uploadPath);
//            }
//            String filename = System.currentTimeMillis() + "_" + file.getOriginalFilename();
//            file.transferTo(new File(uploadDirPath, filename));
//            user.setImg(filename); // 파일 이름을 img 필드에 설정
//            user.setOrgImg(file.getOriginalFilename());
//        }
		int result = userService.createUser(user);
		return new ResponseEntity<>(result, HttpStatus.OK);
	}
	
    // 마이페이지 수정
	@AuthRequired
    @PutMapping("/my-page")
    public ResponseEntity<?> updateUser(HttpServletRequest request, @RequestPart("user") User user, @RequestPart(value = "profile", required = false) MultipartFile file) throws ParseException, IOException{
		String accessToken = request.getHeader("accessToken");
		int userId = jwtUtil.getUserId(accessToken);
		user.setUserId(userId);
		
		// 파일을 저장할 폴더 지정 (자바 폴더 내에 지정)
        Resource res = resLoader.getResource("classpath:/static/resources");
//        //파일 저장할 때 이렇게 resource폴더에 하는게 좋음...
        if(!res.getFile().exists()) {
            res.getFile().mkdirs(); // 두 경로이므로 이겋게해야함.
        }
        
        if (file != null && file.getSize() > 0) {
            // prefix를 포함한 전체 이름
            user.setProfile(System.currentTimeMillis() + "_" + file.getOriginalFilename());
            user.setOrgProfile(file.getOriginalFilename());

            file.transferTo(new File(res.getFile(), user.getProfile()));
        }
        
		int result = userService.updateUser(user);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
    
    // 회원탈퇴
	@AuthRequired
    @DeleteMapping("/my-page")
    public ResponseEntity<?> deleteUser(HttpServletRequest request) throws ParseException{
		String accessToken = request.getHeader("accessToken");
		int userId = jwtUtil.getUserId(accessToken);
		int result = userService.deleteUser(userId);
    	return new ResponseEntity<>(result, HttpStatus.OK);
    }
    
    // 회원가입 폼으로 이동
//    @GetMapping("/sign-up")
//    public ResponseEntity<?> goSignUpForm(){
//        return new ResponseEntity<Void>(HttpStatus.OK);
//    }
    
    // 로그인 폼으로이동
//    @GetMapping("/loginForm")
//    public ResponseEntity<?> goLoginForm(){
//        return new ResponseEntity<Void>(HttpStatus.OK);
//    }
    
    // 로그인 실행
//    @PostMapping("/login")
//    public ResponseEntity<?> doLogin(){
//        return new ResponseEntity<Void>(HttpStatus.OK);
//    }
    
    // 로그아웃 실행
//    @PostMapping("/logout")
//    public ResponseEntity<?> dologOut(){
//        return new ResponseEntity<Void>(HttpStatus.OK);
//    }
    
    // 마이클럽 이동
//    @GetMapping("/my-club")
//    public ResponseEntity<?> goMyClub(){
//        return new ResponseEntity<Void>(HttpStatus.OK);
//    }
    
}

package com.fca.model.service;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fca.model.dao.ClubDao;
import com.fca.model.dto.Club;
import com.fca.model.dto.Member;
import com.fca.model.dto.Payment;
import com.fca.model.dto.Schedule;
import com.fca.model.dto.User;

@Service
public class ClubServiceImpl implements ClubService {
	
	private ClubDao clubDao;
	
	@Autowired
	public ClubServiceImpl(ClubDao clubDao) {
		this.clubDao = clubDao;
	}

	@Override
	public List<Club> getclubList() {
		return clubDao.selectClubAll();
	}

	@Override
	public Club getClub(int clubId) {
		return clubDao.selectClub(clubId);
	}

	@Override
	public List<Map<String, Object>> getMemberList(int clubId) {
		return clubDao.selectMembers(clubId);
	}

	@Override
	public int joinClub(int clubId, int userId) {
		Map<String, Object> map = new HashMap<>();
		map.put("clubId", clubId);
		map.put("userId", userId);
		map.put("position", "클럽원");
		return clubDao.insertMember(map);
	}

	@Transactional
	@Override
	public int createClub(Club club, int userId) {
		int result = clubDao.insertClub(club);
		Map<String, Object> map = new HashMap<>();
		map.put("clubId", club.getClubId());
		map.put("userId", userId);
		map.put("position", "클럽장");
		clubDao.insertMember(map);
		return result;
	}

	@Override
	public Club getNewClub() {
		return clubDao.selectNewClub();
	}

	@Override
	public int deleteMember(int memberId) {
		return clubDao.deleteMember(memberId);
	}

	@Override
	public int updateMember(Member member) {
		return clubDao.updateMember(member);
	}

	@Override
	public int updateClub(Club club) {
		return clubDao.updateClub(club);
	}

	@Override
	public int deleteClub(int clubId) {
		return clubDao.deleteClub(clubId);
	}

	@Override
	public Map<String, Object> getClubReceipt(int clubId, int year, int month) {
		Map<String, Object> resultMap = new HashMap<>();
		
		Date date = new Date(year-1900, month-1, 1);
		Calendar cal = Calendar.getInstance(); 
		cal.setTime(date);
		
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("clubId", clubId);
		paramMap.put("payDate", cal.getTime());
		paramMap.put("case", 1);
		
		System.out.println(paramMap.get("payDate"));
		int lastPayment = clubDao.selectPayments(paramMap);
		int lastCost = clubDao.selectCosts(paramMap);
		int lastMoney = lastPayment - lastCost;
		resultMap.put("lastMoney", lastMoney);
		
		paramMap.remove("payDate");
		paramMap.put("leftPayDate", cal.getTime());
		System.out.println(paramMap.get("leftPayDate"));
		cal.add(Calendar.MONTH, +1);
		paramMap.put("rightPayDate", cal.getTime());
		System.out.println(paramMap.get("rightPayDate"));
		paramMap.put("case", 2);
		
		int currentCost = clubDao.selectCosts(paramMap);
		resultMap.put("currentCost", currentCost);
		
		int currentPayment = clubDao.selectPayments(paramMap);
		resultMap.put("currentPayment", currentPayment);
		
//		List<Map<String, Object>> dateCost = clubDao.selectDateCosts(paramMap);
		Map<String, Object> dateCost = clubDao.selectDateCosts(paramMap);
		System.out.println("dateCost : " + dateCost);
		resultMap.put("dateCost", dateCost);
		
		int currentMoney = lastMoney + currentPayment - currentCost;
		resultMap.put("currentMoney", currentMoney);
		
		List<Map<String, Object>> dateReceipt = clubDao.selectDateReceipts(paramMap);
		resultMap.put("dateReceipt", dateReceipt);
		
		return resultMap;
	}

	@Override
	public Map<String, Object> getPaymentList(int clubId, int year, int month) {
		Map<String, Object> resultMap = new HashMap<>();
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("clubId", clubId);
		
		Date date = new Date(year-1900, month-1, 1);
		Calendar cal = Calendar.getInstance();
		
		cal.setTime(date);
		paramMap.put("leftPayDate", cal.getTime());
		System.out.println(paramMap.get("leftPayDate"));
		
		cal.add(Calendar.MONTH, +1);
		paramMap.put("rightPayDate", cal.getTime());
		System.out.println(paramMap.get("rightPayDate"));
		
		List<Payment> datePayment = clubDao.selectDatePayments(paramMap);
		resultMap.put("datePayment", datePayment);
		
		paramMap.put("case", 2);
		int currentPayment = clubDao.selectPayments(paramMap);
		resultMap.put("currentPayment", currentPayment);		
		
		return resultMap;
	}

	@Override
	public int createPayment(Payment payment) {
		return clubDao.insertPayment(payment);
	}

	@Override
	public List<Club> getMyClubList(int userId) {
		return clubDao.selectMyClub(userId);
	}
}

package com.fca.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fca.model.dao.BoardDao;
import com.fca.model.dto.Board;
import com.fca.model.dto.SearchCondition;

@Service
public class BoardServiceImpl implements BoardService {
	
	private BoardDao boardDao;
	
	@Autowired
	public BoardServiceImpl(BoardDao boardDao) {
		this.boardDao = boardDao;
	}

	// 게시글 전체 조회 (검색)
		@Override
		public List<Board> getBoardList(SearchCondition searchCondition) {
			return boardDao.selectBoardList(searchCondition);
		}

		// 게시글 상세 조회
		@Override
		public Board getBoardDetail(int boardId) {
			boardDao.updateViewCnt(boardId);
			return boardDao.selectBoardDetail(boardId);
		}

		// 게시글 작성
		@Transactional
		@Override
		public boolean createBoard(Board board) {
			return boardDao.insertBoard(board) == 1;
		}

		// 게시글 삭제
		@Transactional
		@Override
		public boolean removeBoard(int id) {
			return boardDao.deleteBoard(id) == 1;
		}

		// 게시글 수정
		@Transactional
		@Override
		public boolean modifyBoard(Board board) {
			return boardDao.updateBoard(board) == 1;
		}
}

import { createRouter, createWebHistory } from "vue-router";
import { useClubStore } from "@/stores/club";
import { useScheduleStore } from "@/stores/schedule";
import { useLoginStore } from "@/stores/login";
import HomeView from "../views/HomeView.vue";
import ClubView from "@/views/ClubView.vue";
import BoardView from "@/views/BoardView.vue";
import BoardCreate from "@/components/board/BoardCreate.vue";
import BoardList from "@/components/board/BoardList.vue";
import BoardUpdate from "@/components/board/BoardUpdate.vue";
import BoardDetail from "@/components/board/BoardDetail.vue";
import KakaoMap from "@/views/KakaoView.vue";
import ClubCreate from "@/components/club/ClubCreate.vue";
import ClubHome from "@/components/club/ClubHome.vue";
import ClubScheduleDetail from "@/components/club/schedule/ClubScheduleDetail.vue";
import ClubScheduleList from "@/components/club/schedule/ClubScheduleList.vue";
import ClubScheduleView from "@/views/ClubScheduleView.vue";
import ClubScheduleDetailReceipt from "@/components/club/schedule/ClubScheduleDetailReceipt.vue";
import ClubHomeView from "@/views/ClubHomeView.vue";
import ClubScheduleDetailReceiptView from "@/views/ClubScheduleDetailReceiptView.vue";
import ClubList from "@/components/club/ClubList.vue";
import MyClubList from "@/components/club/MyClubList.vue";
import LoginView from "@/views/LoginView.vue";
import signUp from "@/components/user/signUp.vue";
import ClubPlaceCreate from "@/components/club/schedule/ClubPlaceCreate.vue";
import ClubScheduleCreate from "@/components/club/schedule/ClubScheduleCreate.vue";
import ClubPlaceUpdate from "@/components/club/schedule/ClubPlaceUpdate.vue";
import ClubScheduleUpdate from "@/components/club/schedule/ClubScheduleUpdate.vue";
import ClubUpdate from "@/components/club/ClubUpdate.vue";
import ClubManageView from "@/views/ClubManageView.vue";
import ClubMember from "@/components/club/ClubMember.vue";
import ClubJoin from "@/components/club/ClubJoin.vue";
import ClubFeeManage from "@/components/club/ClubFeeManage.vue";
import myPageView from "@/components/user/myPage.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    // 메인페이
    { path: "/", name: "home", component: HomeView },
    {
      path: "/login",
      name: "login",
      component: LoginView,
    },
    // 유저관련(components/common/TheHeaderNav.vue)
    {
      path: "/myPage",
      name: "myPage",
      component: myPageView,
    },
    {
      path: "/signUp",
      name: "signUp",
      component: signUp,
    },
    { path: "/clubCreate", name: "clubCreate", component: ClubCreate },
    {
      path: "/clubJoin/:clubId",
      name: "ClubJoin",
      component: ClubJoin,
    },

    /// 여기까지가 파라미터 X

    // 클럽 관련
    {
      path: "/club",
      name: "club",
      component: ClubView,
      children: [
        {
          path: "",
          name: "clubList",
          component: ClubList,
        },
        {
          path: "myclublist",
          name: "myClubList",
          component: MyClubList,
        },
        // 여기까지 공통으로 꺼내 쓸수 있는 친구들
        // clubId 파라미터를 필수로 갖고 있는 컴포넌트
        {
          path: ":clubId",
          name: "clubHomeView",
          component: ClubHomeView,
          beforeEnter: (to, from, next) => {
            const clubStore = useClubStore();
            const clubId = Number(to.params.clubId); // Convert clubId to a number
            // if (!clubStore.MyClubIdList.includes(clubId)) {
            // alert("클럽에 가입되어 있지 않습니다.");
            // next({ name: "ClubJoin", params: { clubId: to.params.clubId } });
            // } else {
            // next();
            // }
            let isMyClub = false;
            clubStore.MyClubList.forEach((MyClub) => {
              console.log(MyClub.clubId);
              console.log(clubId);
              if (MyClub.clubId == clubId) {
                isMyClub = true;
              }
            });
            if (isMyClub) {
              next();
            } else {
              alert("클럽에 가입되어 있지 않습니다.");
              next({
                name: "ClubJoin",
                params: { clubId: to.params.clubId },
              });
            }
          },
          children: [
            {
              path: "",
              name: "clubHome",
              component: ClubHome,
            },

            {
              path: "placeCreate",
              name: "placeCreate",
              component: ClubPlaceCreate,
            },
            {
              path: ":placeId",
              name: "ClubScheduleCreate",
              component: ClubScheduleCreate,
            },
            {
              path: "placeUpdate/:placeId",
              name: "ClubPlaceUpdate",
              component: ClubPlaceUpdate,
            },
            {
              path: "pay/:clubFee/:name",
              name: "pay",
              component: () => import("../views/CheckoutView.vue"),
            },

            {
              path: "schedule",
              name: "clubSchedule",
              beforeEnter: (to, from, next) => {
                const store = useScheduleStore();
                if (!store.isScheduleIn()) {
                  alert("일정이 없습니다!");
                  next({ name: "placeCreate" });
                } else {
                  next();
                }
              },
              component: ClubScheduleView,
              children: [
                {
                  path: "",
                  name: "clubScheduleList",
                  component: ClubScheduleList,
                },
                {
                  path: ":scheduleId",
                  name: "clubScheduleDetail",
                  component: ClubScheduleDetail,
                },
                {
                  path: "scheduleUpdate/:scheduleId",
                  name: "ClubScheduleUpdate",
                  component: ClubScheduleUpdate,
                },
                {
                  path: "receipt",
                  name: "clubScheduleDetailReceiptView",
                  component: ClubScheduleDetailReceiptView,
                  children: [
                    {
                      path: ":receiptDate",
                      name: "clubScheduleDetailReceipt",
                      component: ClubScheduleDetailReceipt,
                    },
                  ],
                },
              ],
            },
            {
              path: "board",
              name: "boardView",
              component: BoardView,
              children: [
                { path: "", name: "boardList", component: BoardList },
                { path: "create", name: "boardCreate", component: BoardCreate },
                { path: "update", name: "boardUpdate", component: BoardUpdate },
                {
                  path: ":boardId",
                  name: "boardDetail",
                  component: BoardDetail,
                },
              ],
            },
            {
              path: "manage",
              name: "ClubManageView",
              component: ClubManageView,
              children: [
                {
                  path: "clubUpdate",
                  name: "ClubUpdate",
                  component: ClubUpdate,
                },
                {
                  path: "clubMember",
                  name: "ClubMember",
                  component: ClubMember,
                },
                {
                  path: "clubFeeManage",
                  name: "ClubFeeManage",
                  component: ClubFeeManage,
                },
              ],
            },
          ],
        },
      ],
    },

    { path: "/kakao", name: "kakao", component: KakaoMap },
    {
      path: "/success/:clubId",
      name: "success",
      component: () => import("../views/SuccessView.vue"),
    },
    {
      path: "/fail/:clubId",
      name: "fail",
      component: () => import("../views/FailView.vue"),
    },
  ],
});

router.beforeEach((to, from, next) => {
  const store = useLoginStore();
  console.log(to.name);
  // home, login, signup 페이지를 제외한 모든 경로에 대해 requiresAuth 검사
  if (
    ![
      "home",
      "login",
      "signUp",
      "ClubJoin",
      "clubList",
      "clubHome",
      "clubHomeView",
    ].includes(to.name) &&
    // !store.accessToken
    !sessionStorage.getItem("accessToken")
  ) {
    alert("로그인이 필요합니다.");
    next({ name: "login" }); // 로그인 페이지로 리디렉션
  } else {
    next(); // 페이지 이동 허용
  }
});
export default router;

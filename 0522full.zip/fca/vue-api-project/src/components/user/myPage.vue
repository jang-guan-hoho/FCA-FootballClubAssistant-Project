<template>
  <div>
    <h2>My Page</h2>
    <form @submit.prevent="updateProfile">
      <div>
        <label for="name">Name:</label>
        <input type="text" id="name" v-model="profile.name" required readonly />
      </div>
      <div>
        <label for="email">Email:</label>
        <input type="email" id="email" v-model="profile.email" readonly />
      </div>
      <div>
        <label for="password">New Password:</label>
        <input type="password" id="password" v-model="newPassword" />
      </div>
      <div>
        <label for="passwordConfirm">Confirm New Password:</label>
        <input
          type="password"
          id="passwordConfirm"
          v-model="newPasswordConfirm"
        />
      </div>
      <div>
        <label for="gender">Gender:</label>
        <select id="gender" v-model="profile.gender" required>
          <option value="true">Male</option>
          <option value="false">Female</option>
        </select>
      </div>
      <div>
        <label for="birth">Birth Date:</label>
        <input type="date" id="birth" v-model="profile.birth" required />
      </div>
      <div>
        <label for="intro">Introduction:</label>
        <textarea id="intro" v-model="profile.intro"></textarea>
      </div>
      <div>
        <label for="profile">Profile Picture:</label>
        <input type="file" id="profile" @change="handleProfileUpload" />
        <img
          :src="profilePreview"
          alt="Profile Picture"
          v-if="profilePreview"
        />
      </div>
      <button type="submit">Update Profile</button>
      <p v-if="errorMessage" class="error">{{ errorMessage }}</p>
    </form>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useLoginStore } from "@/stores/login";
import axios from "axios";

const store = useLoginStore();
const profile = ref({ ...store.loginUser });

const newPassword = ref("");
const newPasswordConfirm = ref("");
const profilePreview = ref(
  profile.value.profile ? URL.createObjectURL(profile.value.profile) : null
);
const errorMessage = ref(null);

const handleProfileUpload = (event) => {
  const file = event.target.files[0];
  profile.value.profile = file;
  profilePreview.value = URL.createObjectURL(file);
};

const updateProfile = async () => {
  if (newPassword.value && newPassword.value !== newPasswordConfirm.value) {
    errorMessage.value = "비밀번호가 일치하지 않습니다.";
    return;
  }

  const formData = new FormData();
  formData.append("userId", profile.value.userId);
  formData.append("name", profile.value.name);
  formData.append("gender", profile.value.gender);
  formData.append("birth", profile.value.birth);
  formData.append("intro", profile.value.intro);
  if (newPassword.value) {
    formData.append("password", newPassword.value);
  }
  if (profile.value.profile instanceof File) {
    formData.append("profile", profile.value.profile);
  }

  try {
    const res = await axios.put(
      `http://localhost:8080/user/${profile.value.userId}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          accessToken: store.accessToken,
        },
      }
    );
    alert("프로필 수정 성공!");
    store.loginUser = { ...profile.value };
    errorMessage.value = null;
  } catch (error) {
    console.error("프로필 수정 실패:", error);
    errorMessage.value = "프로필 수정에 실패했습니다. 다시 시도해주세요.";
  }
};

onMounted(() => {
  profile.value = { ...store.loginUser };
  if (profile.value.profile && !(profile.value.profile instanceof File)) {
    profilePreview.value = profile.value.profile;
  }
  console.log(profile.value);
});
</script>

<style scoped>
form div {
  margin-bottom: 1em;
}
form label {
  display: block;
  margin-bottom: 0.5em;
}
form input,
form textarea,
form select {
  width: 100%;
  padding: 0.5em;
}
form img {
  max-width: 100px;
  display: block;
  margin-top: 1em;
}
.error {
  color: red;
  margin-top: 1em;
}
</style>

<template>
  <div>
    <h2>Receipt</h2>
    <h4>
      <!-- <div @click="decrementMonth">&lt;</div>
      {{ year }} / {{ month }}
      <div @click="incrementMonth">&gt;</div> -->
      <div class="date-navigation">
        <button @click="decrementMonth">&lt;</button>
        <span>{{ year }}년 {{ month }}월</span>
        <button @click="incrementMonth">&gt;</button>
      </div>
      <table>
        <tr>
          <td>이월 회비 : {{ store.receiptMap.lastMoney }}</td>
          <td></td>
        </tr>
      </table>
    </h4>
  </div>
</template>

<script setup>
import { useScheduleStore } from "@/stores/schedule";
import ClubInfoBar from "../common/ClubInfoBar.vue";
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";
const store = useScheduleStore();
const route = useRoute();

const nowDate = new Date();
const year = ref(nowDate.getFullYear());
const month = ref(nowDate.getMonth() + 1);
const newDate = ref("");
// const resultMap = ref({});

function handleDateChange(yearValue, monthValue) {
  // JavaScript Date 객체는 월을 0부터 시작하기 때문에 -1을 해야 합니다.
  //   const date = new Date(yearValue, monthValue - 1);
  //   year.value = date.getFullYear();
  //   month.value = date.getMonth() + 1; // 월을 다시 1부터 시작으로 조정
  // 필요한 API 호출 또는 상태 업데이트 로직
  // 이값들로 date 형식 'YYYY-MM-DD'
  newDate.value = year.value + "-" + month.value;
  store.getReceiptMap(route.params.clubId, newDate.value);
  //   resultMap.value = store.receiptMap;
}

const incrementMonth = () => {
  if (month.value === 12) {
    year.value += 1;
    month.value = 1;
  } else {
    month.value += 1;
  }
  //   const newMonth = parseInt(month.value) + 1;
  //   handleDateChange(year.value, month.value);
  handleDateChange();
};

const decrementMonth = () => {
  if (month.value === 1) {
    year.value -= 1;
    month.value = 12;
  } else {
    month.value -= 1;
  }
  //   const newMonth = parseInt(month.value) - 1;
  //   handleDateChange(year.value, month.value);
  handleDateChange();
};

onMounted(() => {
  newDate.value = year.value + "-" + month.value;
  store.getReceiptMap(route.params.clubId, newDate.value);
  //   console.log(store.receiptMap);
  //   resultMap.value = store.receiptMap;
  //   console.log(resultMap.value);
  //   const date = route.params.receiptDate;
  //   const dateParts = date.split("-");
  //   year.value = dateParts[0];
  //   month.value = parseInt(dateParts[1]); // 문자열을 숫자로 변환
  //   newDate.value = year.value + "-" + month.value;
});
</script>

<style scoped>
a {
  cursor: pointer; /* 링크 커서 스타일 */
  margin: 0 10px; /* 좌우 여백 */
}

.receipt-report {
  font-family: "Arial, sans-serif";
  width: 300px;
  margin: auto;
  text-align: center;
}

.date-navigation {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 20px;
}

th,
td {
  border: 1px solid #000;
  padding: 8px;
  text-align: left;
}

.total {
  margin-top: 20px;
  text-align: right;
}
</style>

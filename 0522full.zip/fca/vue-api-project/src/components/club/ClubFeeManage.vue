<template>
  <div class="receipt-report">
    <div class="date-navigation">
      <button @click="decrementMonth">&lt;</button>
      <span>{{ year }}년 {{ month }}월</span>
      <button @click="incrementMonth">&gt;</button>
    </div>

    <table>
      <thead>
        <tr>
          <th>이름</th>
          <th>회비 납부금</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(member, index) in paidMemberInfo" :key="member.userId">
          <td>{{ member.name }}</td>
          <td>{{ formatCurrency(paidMemberList[0].price) }}</td>
          <!-- <td>{{ formatCurrency(store.club.fee) }}</td> -->
        </tr>
      </tbody>
    </table>

    <div class="total">
      <h3>총액: {{ formatCurrency(totalAmount) }} 원</h3>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from "vue";
import axios from "axios";
import { useClubStore } from "@/stores/club";
import { useRoute } from "vue-router";

const route = useRoute();
const store = useClubStore();

const nowDate = new Date();
const year = ref(nowDate.getFullYear());
const month = ref(nowDate.getMonth() + 1);
const accessToken = sessionStorage.getItem("accessToken");
const paidMemberList = ref([]);
const paidMemberId = ref([]);
const paidMemberInfo = ref([]);

const fetchData = () => {
  const formattedMonth = String(month.value).padStart(2, "0");
  const url = `http://localhost:8080/fca/club/${route.params.clubId}/manage/receipt/${year.value}-${formattedMonth}`;

  axios
    .get(url, {
      headers: { accessToken: accessToken },
    })
    .then((response) => {
      paidMemberList.value = response.data.datePayment;
      console.log(paidMemberList.value);

      paidMemberList.value.forEach((pm) => {
        paidMemberId.value.push(pm.userId);
      });

      paidMemberInfo.value = store.clubMember.filter((member) =>
        paidMemberId.value.includes(member.userId)
      );
    })
    .catch((error) => {
      console.error("Error fetching data", error);
    });
};

const incrementMonth = () => {
  if (month.value === 12) {
    year.value += 1;
    month.value = 1;
  } else {
    month.value += 1;
  }
  fetchData();
};

const decrementMonth = () => {
  if (month.value === 1) {
    year.value -= 1;
    month.value = 12;
  } else {
    month.value -= 1;
  }
  fetchData();
};

// const paidMembers = computed(() => {
//   return store.clubMember.filter((member) =>
//     payedMemberList.value.includes(member.userId)
//   );
// });

// const totalAmount = computed(() => {
//   return paidMemberList.value.reduce(
//     (sum, member) => sum + (store.club.fee || 0),
//     0
//   );
// });

const totalAmount = computed(() => {
  return paidMemberList.value.reduce(
    (sum, member) => sum + (member.price || 0),
    0
  );
});

// const totalAmount = computed(() => {
//   return paidMemberList.value.length * store.club.fee;
// });

const formatCurrency = (amount) => {
  if (amount == null) {
    amount = 0;
  }
  return amount.toLocaleString("ko-KR", { style: "currency", currency: "KRW" });
};

onMounted(() => {
  fetchData();
});
</script>

<style scoped>
.receipt-report {
  font-family: "Arial, sans-serif";
  width: 300px;
  margin: auto;
  text-align: center;
}

.date-navigation {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 20px;
}

th,
td {
  border: 1px solid #000;
  padding: 8px;
  text-align: left;
}

.total {
  margin-top: 20px;
  text-align: right;
}
</style>

<template>
  <div id="container">
    <header>
      <nav>
        <RouterLink to="/">logo</RouterLink> |
        <RouterLink :to="{ name: 'clubCreate' }">clubCrete</RouterLink> |
        <RouterLink :to="{ name: 'club' }">clubHome</RouterLink>
      </nav>
      <RouterLink v-if="loginStore.accessToken === ''" to="/login"
        >Login</RouterLink
      >
      <button v-else @click="logout">Logout</button>
      <RouterLink :to="{ name: 'signUp' }">회원가입</RouterLink>
      <RouterLink :to="{ name: 'myPage' }">마이페이지</RouterLink>
    </header>
  </div>
</template>

<script setup>
import { useClubStore } from "@/stores/club";
import { useLoginStore } from "@/stores/login";
import { onMounted, ref, computed } from "vue";
const loginStore = useLoginStore();
const hasAccessToken = computed(() => {
  return sessionStorage.getItem("accessToken");
});
const logout = () => {
  loginStore.logout();
};
</script>

<style scoped>
#container {
  text-align: center;
}

nav a {
  font-weight: bold;
  text-decoration: none;
  color: black;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>

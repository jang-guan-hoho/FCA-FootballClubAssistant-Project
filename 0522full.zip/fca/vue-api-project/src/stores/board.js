import { ref, computed } from "vue";
import { defineStore } from "pinia";
import axios from "axios";
import router from "@/router";
import { useLoginStore } from "./login";

const REST_BOARD_API = `http://localhost:8080/api-board/board`;
export const useBoardStore = defineStore(
  "board",
  () => {
    const loginStore = useLoginStore();
    const board = ref({});
    const boardList = ref([]);

    const createBoard = function (boardData) {
      const formData = new FormData();
      Object.keys(boardData).forEach((key) => {
        if (boardData[key] instanceof File) {
          formData.append(key, boardData[key], boardData[key].name);
        } else {
          formData.append(key, boardData[key]);
        }
      });

      return axios({
        url: REST_BOARD_API,
        method: "POST",
        data: formData,
        headers: { accessToken: loginStore.accessToken },
      })
        .then((response) => {
          router.push({ name: "boardList" });
        })
        .catch((err) => {
          console.error("Error creating board:", err);
        });
    };

    const getBoardList = function (clubId) {
      axios
        .get(`${REST_BOARD_API}/${clubId}`, {
          headers: { accessToken: loginStore.accessToken },
        })
        .then((response) => {
          boardList.value = response.data;
        });
    };

    const getBoard = function (boardId) {
      axios
        .get(`${REST_BOARD_API}/${boardId}`, {
          headers: { accessToken: loginStore.accessToken },
        })
        .then((response) => {
          board.value = response.data;
        });
    };

    const searchBoardList = function (searchCondition) {
      axios
        .get(REST_BOARD_API, {
          params: searchCondition,
          headers: { accessToken: loginStore.accessToken },
        })
        .then((res) => {
          boardList.value = res.data;
        });
    };

    return {
      createBoard,
      boardList,
      getBoardList,
      board,
      getBoard,
      searchBoardList,
    };
  },
  { persist: true }
);

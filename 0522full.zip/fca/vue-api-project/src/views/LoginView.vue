<template>
  <div>
    <h1>Login View</h1>
    <form @submit.prevent="handleLogin">
      <input type="text" placeholder="email" v-model="email" />
      <input type="password" placeholder="password" v-model="password" />

      <button>login</button>
    </form>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useLoginStore } from "@/stores/login";

const loginStore = useLoginStore();
const email = ref("");
const password = ref("");

const handleLogin = () => {
  const userInfo = {
    email: email.value,
    password: password.value,
  };

  loginStore.login(userInfo);
};
</script>

<style scoped></style>

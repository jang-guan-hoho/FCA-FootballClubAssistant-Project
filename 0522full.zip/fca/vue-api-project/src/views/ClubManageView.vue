<template>
    <div>
        // 클럽삭제
        <div @click="deleteClub">클럽 삭제</div>
        <RouterLink :to="{name:'ClubUpdate', params:{clubId:route.params.clubId}}">클럽 수정하기</RouterLink>|
        <RouterLink :to="{name:'ClubMember', params:{clubId:route.params.clubId}}">클럽 맴버관리</RouterLink>|
        <RouterLink :to="{name:'ClubFeeManage', params:{clubId:route.params.clubId}}">클럽 회비관리</RouterLink>|
        <RouterView />
    </div>
</template>

<script setup>

import { useRoute } from 'vue-router';
import { useClubStore } from '@/stores/club';
import { onMounted } from 'vue';
import axios from 'axios';

const accessToken = sessionStorage.getItem('accessToken')
const route = useRoute();
const store = useClubStore();
const deleteClub = function(){
  axios.delete(`http://localhost:8080/fca/club/${route.params.clubId}/manage`,{
    headers:{'accessToken':accessToken}
  })
    .then(() => {
            router.push({ name: 'home' })
        })
}
onMounted(async () => {
  await store.getClub(route.params.clubId); // 클럽 정보를 가져오는 메서드
});
</script>

<style scoped>
h1 {
  font-size: 24px;
}
</style>
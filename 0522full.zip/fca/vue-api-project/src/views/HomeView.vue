<template>
  
  <div>
    <h2>HomeView</h2>
    <ClubList />
  </div>
</template>

<script setup>
import ClubList from '@/components/club/ClubList.vue';
</script>

<style scoped>
div{
  background-image: url('/tossVue/fca/vue-api-project/src/assets/img/background.PNG');
}
</style>

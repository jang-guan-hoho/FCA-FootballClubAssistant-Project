package com.fca.model.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fca.model.dao.BoardDao;
import com.fca.model.dto.Board;
import com.fca.model.dto.SearchCondition;

@Service
public class BoardServiceImpl implements BoardService {
    
    private BoardDao boardDao;
    
    @Autowired
    public BoardServiceImpl(BoardDao boardDao) {
        this.boardDao = boardDao;
    }

    // 게시글 전체 조회 (검색)
        @Override
        public List<Board> getBoardList(int clubId, SearchCondition searchCondition) {
            Map<String, Object> paramMap = new HashMap<>();
            paramMap.put("clubId", clubId);
            paramMap.put("key", searchCondition.getKey());
            paramMap.put("word", searchCondition.getWord());
            paramMap.put("orderBy", searchCondition.getOrderBy());
            paramMap.put("orderByDir", searchCondition.getOrderByDir());
            return boardDao.selectBoardList(paramMap);
        }

        // 게시글 상세 조회
        @Override
        public Board getBoardDetail(int boardId) {
            boardDao.updateViewCnt(boardId);
            return boardDao.selectBoardDetail(boardId);
        }

        // 게시글 작성
        @Transactional
        @Override
        public boolean createBoard(Board board) {
            return boardDao.insertBoard(board) == 1;
        }

        // 게시글 삭제
        @Transactional
        @Override
        public boolean removeBoard(int id) {
            return boardDao.deleteBoard(id) == 1;
        }

        // 게시글 수정
        @Transactional
        @Override
        public boolean modifyBoard(Board board) {
            return boardDao.updateBoard(board) == 1;
        }

        @Override
        public Board getNewBoard() {
            return boardDao.selectNewBoard();
        }
}

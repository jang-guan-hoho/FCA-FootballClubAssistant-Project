package com.fca.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fca.annotation.AuthRequired;
import com.fca.model.dto.Club;
import com.fca.model.dto.Participant;
import com.fca.model.dto.Place;
import com.fca.model.dto.Receipt;
import com.fca.model.dto.Schedule;
import com.fca.model.service.ScheduleService;
import com.fca.util.JwtUtil;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/fca")
@Tag(name = "ScheduleRestController", description = "Schedule CRUD")
public class ScheduleRestController {
	
	private ScheduleService scheduleService;
	
	private JwtUtil jwtUtil;
	
	@Autowired
	public ScheduleRestController(ScheduleService scheduleService, JwtUtil jwtUtil) {
		this.scheduleService = scheduleService;
		this.jwtUtil = jwtUtil;
	}
	
	// 클럽 일정 이동 + 나의 일정 같이 표시하면 좋겠음 달력에 --> 일단 리스트만 받는걸로 만들기
	@AuthRequired
    @GetMapping("/club/{clubId}/schedule")
    public ResponseEntity<?> goClubSchedule(@PathVariable("clubId") int clubId, HttpServletRequest request) throws ParseException{
		String accessToken = request.getHeader("accessToken");
		int userId = jwtUtil.getUserId(accessToken);
    	Map<String, Object> resultMap = scheduleService.getScheduleIdList(clubId, userId);
        return new ResponseEntity<>(resultMap, HttpStatus.OK);
    }
    
    // 장소 생성
	@AuthRequired
	@PostMapping("/club/{clubId}/place")
    public ResponseEntity<?> createPlace(@RequestBody Place place){
    	scheduleService.createPlace(place);
    	Place newPlace = scheduleService.getNewPlace();
    	return new ResponseEntity<>(newPlace, HttpStatus.OK);
    }    
    
    // 클럽 일정 생성
	@AuthRequired
    @PostMapping("/club/{clubId}/schedule")
    public ResponseEntity<?> createClubSchedule(@PathVariable("clubId") int clubId, @RequestBody Schedule schedule){
    	schedule.setClubId(clubId);
    	int result = scheduleService.createClubSchedule(schedule);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
    
    // 클럽 일정 상세
	@AuthRequired
    @GetMapping("/club/{clubId}/schedule/{scheduleId}")
    public ResponseEntity<?> clubScheduleDetail(@PathVariable("scheduleId") int scheduleId){
    	Map<String, Object> resultMap = scheduleService.getScheduleDetail(scheduleId);
    	return new ResponseEntity<>(resultMap, HttpStatus.OK);
    }
    
    // 장소 수정
	@AuthRequired
    @PutMapping("/club/{clubId}/place/{placeId}")
    public ResponseEntity<?> placeUpdate(@RequestBody Place place, @PathVariable("placeId") int placeId){
    	place.setPlaceId(placeId);
    	int result = scheduleService.updatePlace(place);
    	return new ResponseEntity<>(result, HttpStatus.OK);
    }
    
    // 클럽 일정 수정
	@AuthRequired
    @PutMapping("/club/{clubId}/schedule/{scheduleId}")
    public ResponseEntity<?> clubScheduleUpdate(@RequestBody Schedule schedule){
    	int result = scheduleService.updateSchedule(schedule);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
    
    // 클럽 일정 삭제
	@AuthRequired
    @DeleteMapping("/club/{clubId}/schedule/{scheduleId}")
    public ResponseEntity<?> clubScheduleDelete(@PathVariable("scheduleId") int scheduleId){
    	int result = scheduleService.deleteSchedule(scheduleId);
    	return new ResponseEntity<>(result, HttpStatus.OK);
    }
    
    // 일정 참여
	@Transactional
	@AuthRequired
    @PostMapping("/club/{clubId}/schedule/{scheduleId}/participant")
    public ResponseEntity<?> clubScheduleParticipantCreate(@PathVariable("scheduleId") int scheduleId, @PathVariable("clubId") int clubId, HttpServletRequest request) throws ParseException{
		String accessToken = request.getHeader("accessToken");
		int userId = jwtUtil.getUserId(accessToken);
    	scheduleService.createParticipant(scheduleId, clubId, userId);
    	List<Participant> participantList = scheduleService.getParticipantList(scheduleId);
    	return new ResponseEntity<>(participantList, HttpStatus.OK);
    }
    
    // 일정 취소
	@Transactional
	@AuthRequired
    @DeleteMapping("/club/{clubId}/schedule/{scheduleId}/participant/{participantId}")
    public ResponseEntity<?> clubScheduleParticipantDelete(@PathVariable("participantId") int participantId, @PathVariable("scheduleId") int scheduleId){
    	scheduleService.deleteParticipant(participantId);
    	List<Participant> participantList = scheduleService.getParticipantList(scheduleId);
    	return new ResponseEntity<>(participantList, HttpStatus.OK);
    }
        
    // 클럽 일정 회비 이동
//    @GetMapping("/club/{clubId}/schedule/{scheduleId}/receipt")
//    public ResponseEntity<?> goClubScheduleReceipt(){
//        return new ResponseEntity<Void>(HttpStatus.OK);
//    }
    
    // 클럽 일정 회비 등록
	@Transactional
	@AuthRequired
    @PostMapping("/club/{clubId}/schedule/{scheduleId}/receipt")
    public ResponseEntity<?> clubScheduleReceiptCreate(@PathVariable("scheduleId") int scheduleId, @RequestBody Receipt receipt){
        receipt.setScheduleId(scheduleId);
        scheduleService.createReceipt(receipt);
        List<Receipt> receiptList = scheduleService.getreceiptList(scheduleId);
    	return new ResponseEntity<>(receiptList, HttpStatus.OK);
    }
    
    // 클럽 일정 회비 삭제
	@Transactional
	@AuthRequired
    @DeleteMapping("/club/{clubId}/schedule/{scheduleId}/receipt/{receiptId}")
    public ResponseEntity<?> clubScheduleReceiptDelete(@PathVariable("receiptId") int receiptId, @PathVariable("scheduleId") int scheduleId){
    	scheduleService.deleteReceipt(receiptId);
    	List<Receipt> receiptList = scheduleService.getreceiptList(scheduleId);
        return new ResponseEntity<>(receiptList, HttpStatus.OK);
    }
}

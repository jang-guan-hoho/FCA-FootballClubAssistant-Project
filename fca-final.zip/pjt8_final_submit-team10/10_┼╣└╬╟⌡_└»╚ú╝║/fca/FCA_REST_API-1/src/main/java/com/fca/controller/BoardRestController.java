package com.fca.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fca.annotation.AuthRequired;
import com.fca.model.dto.Board;
import com.fca.model.dto.SearchCondition;
import com.fca.model.dto.User;
import com.fca.model.service.BoardService;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/fca")
@Tag(name = "BoardRestController", description = "Board CRUD")
public class BoardRestController {
    
    private static final String SUCCESS = "success";
    private static final String FAIL = "fail";
    
    private BoardService boardService;
    
    @Autowired
    public BoardRestController(BoardService boardService) {
        this.boardService = boardService;
    }
    
    // 클럽 게시판 이동
    @AuthRequired
    @GetMapping("/club/{clubId}/board")
    public ResponseEntity<?> goClubBoardList(@PathVariable("clubId") int clubId, @ModelAttribute SearchCondition condition){
        List<Board> list = boardService.getBoardList(clubId, condition); // 검색 조회
        if (list == null || list.size() == 0)
            return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
        return new ResponseEntity<List<Board>>(list, HttpStatus.OK);
    }
    
    // 클럽 게시판 생성
    @AuthRequired
    @PostMapping("/club/{clubId}/board")
    public ResponseEntity<?> createClubBoard(@RequestPart("board") Board board, @RequestPart(value = "file", required = false) MultipartFile file) throws IOException{
        handleFileUpload(board, file);
        boardService.createBoard(board);
        Board newboard = boardService.getNewBoard();
        return new ResponseEntity<Board>(newboard, HttpStatus.CREATED);
    }
    
    // 클럽 게시판 상세
    @AuthRequired
    @GetMapping("/club/{clubId}/board/{boardId}")
    public ResponseEntity<?> clubBoardDetail(@PathVariable("boardId") int boardId){
        Board board = boardService.getBoardDetail(boardId);
        if (board != null)
            return new ResponseEntity<Board>(board, HttpStatus.OK);
        return new ResponseEntity<Board>(HttpStatus.NOT_FOUND);
    }
    
    // 클럽 게시판 수정
    @AuthRequired
    @PutMapping("/club/{clubId}/board/{boardId}")
    public ResponseEntity<?> clubBoardUpdate(@RequestBody Board board, @PathVariable("boardId") int boardId){
        board.setBoardId(boardId);
        if (boardService.modifyBoard(board))
            return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
        return new ResponseEntity<String>(FAIL, HttpStatus.BAD_REQUEST);
    }
    
    // 클럽 게시판 삭제
    @AuthRequired
    @DeleteMapping("/club/{clubId}/board/{boardId}")
    public ResponseEntity<?> clubBoardDelete(@PathVariable("boardId") int boardId){
        if (boardService.removeBoard(boardId))
            return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
        return new ResponseEntity<String>(FAIL, HttpStatus.NOT_FOUND);
    }
    
    private void handleFileUpload(Board board, MultipartFile file) throws IOException {
        if (file != null && !file.isEmpty()) {
            // 파일을 저장할 폴더 지정 (프로젝트의 절대 경로)
            String uploadDir = System.getProperty("user.dir") + "/src/main/resources/static/resources/";
            Path uploadPath = Paths.get(uploadDir);
            
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }
            
            String fileName = System.currentTimeMillis() + "_" + StringUtils.cleanPath(file.getOriginalFilename());
            Path filePath = uploadPath.resolve(fileName);
            Files.copy(file.getInputStream(), filePath);
            
            board.setFile(fileName);
            board.setOrgFile(file.getOriginalFilename());
        }
    }
}

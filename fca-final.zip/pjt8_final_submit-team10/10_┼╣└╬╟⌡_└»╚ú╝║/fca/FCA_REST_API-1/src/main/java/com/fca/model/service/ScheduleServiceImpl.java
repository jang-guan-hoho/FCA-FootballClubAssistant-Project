package com.fca.model.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fca.model.dao.ScheduleDao;
import com.fca.model.dto.Club;
import com.fca.model.dto.Participant;
import com.fca.model.dto.Place;
import com.fca.model.dto.Receipt;
import com.fca.model.dto.Schedule;

@Service
public class ScheduleServiceImpl implements ScheduleService {

	private ScheduleDao scheduleDao;
	
	@Autowired
	public ScheduleServiceImpl(ScheduleDao scheduleDao) {
		this.scheduleDao = scheduleDao;
	}
	
	@Override
	public Map<String, Object> getScheduleIdList(int clubId, int userId) {
		Map<String, Object> resultMap = new HashMap<>();
		List<Schedule> scheduleList = scheduleDao.selectScheduleList(clubId);
		resultMap.put("scheduleList", scheduleList);
		
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("clubId", clubId);
		paramMap.put("userId", userId);
		List<Integer> myScheduleIdList = scheduleDao.selectMyScheduleIdList(paramMap);
		resultMap.put("myScheduleIdList", myScheduleIdList);
		return resultMap;
	}
	
	@Override
	public int createPlace(Place place) {
		return scheduleDao.insertPlace(place);
	}
	
	@Override
	public Place getNewPlace() {
		return scheduleDao.selectNewPlace();
	}

	@Override
	public int createClubSchedule(Schedule schedule) {
		return scheduleDao.insertSchedule(schedule);
	}
	
	@Override
	public Map<String, Object> getScheduleDetail(int scheduleId) {
		Map<String, Object> resultMap = new HashMap<>();
		Place place = scheduleDao.selectPlace(scheduleId);
		resultMap.put("place", place);
		List<Receipt> receiptList = scheduleDao.selectReceipt(scheduleId);
		resultMap.put("receiptList", receiptList);
		List<Participant> participantList = scheduleDao.selectParticipant(scheduleId);
		resultMap.put("participantList", participantList);
		return resultMap;
	}
	
	@Override
	public int updatePlace(Place place) {
		return scheduleDao.updatePlace(place);
	}

	@Override
	public int updateSchedule(Schedule schedule) {
		return scheduleDao.updateSchedule(schedule);
	}

	@Override
	public int deleteSchedule(int scheduleId) {
		return scheduleDao.deleteSchedule(scheduleId);
	}

	@Transactional
	@Override
	public int createParticipant(int scheduleId, int clubId, int userId) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("scheduleId", scheduleId);
		paramMap.put("userId", userId);
		int result = scheduleDao.insertParticipant(paramMap);
		Date currentDate = scheduleDao.selectCurrentDate(scheduleId);
		paramMap.remove("scheduleId");
		paramMap.put("clubId", clubId);
		paramMap.put("currentDate", currentDate);
		result += scheduleDao.updateMemberCurrentDate(paramMap);
		return result;
	}

	@Override
	public int deleteParticipant(int participantId) {
		return scheduleDao.deleteParticipant(participantId);
	}

    @Transactional
    @Override
    public int createReceipt(Receipt receipt) {
        scheduleDao.insertReceipt(receipt);
        return scheduleDao.plusMoney(receipt);
    }

    @Transactional
    @Override
    public int deleteReceipt(int receiptId) {
        Receipt receipt = scheduleDao.selectDeleteReceipt(receiptId);
        scheduleDao.deleteReceipt(receiptId);
        return scheduleDao.minusMoney(receipt);
    }

	@Override
	public List<Participant> getParticipantList(int scheduleId) {
		return scheduleDao.selectParticipant(scheduleId);
	}

	@Override
	public List<Receipt> getreceiptList(int scheduleId) {
		return scheduleDao.selectReceipt(scheduleId);
	}
}

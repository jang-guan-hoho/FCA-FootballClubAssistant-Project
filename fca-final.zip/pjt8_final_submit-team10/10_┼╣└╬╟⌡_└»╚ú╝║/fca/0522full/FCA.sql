DROP SCHEMA IF EXISTS FCA;
CREATE SCHEMA IF NOT EXISTS FCA;
USE FCA;


CREATE TABLE `club` (
	`club_id` INT NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(200) NOT NULL,
	`max_member` INT NOT NULL COMMENT 'maximum 100',
	`content` TEXT NOT NULL COMMENT 'placehold',
	`fee` INT NOT NULL COMMENT '1000~',
	`deadline` INT NOT NULL COMMENT '1~28',
	`logo` VARCHAR(200) NULL DEFAULT 'default_logo',
	`account`  VARCHAR(400) NOT NULL,
	`bank` VARCHAR(200) NOT NULL,
	`region` VARCHAR(200) NOT NULL,
    `money` int NULL DEFAULT 0,
	PRIMARY KEY (`club_id`)
);
CREATE TABLE `user` (
	`user_id` INT NOT NULL AUTO_INCREMENT,
	`email` VARCHAR(200) NOT NULL,
	`password` VARCHAR(200) NOT NULL,
	`name` VARCHAR(200) NOT NULL,
	`gender` BOOLEAN NOT NULL COMMENT '남 - M / 여 - F',
	`birth` DATE NOT NULL,
	`intro` TEXT NOT NULL COMMENT 'placehold',
	`profile` VARCHAR(200) NULL,
    -- `profile` VARCHAR(200) NULL DEFAULT 'default_profile',
	PRIMARY KEY (`user_id`)
);
CREATE TABLE `place` (
	`place_id` INT NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(200) NOT NULL,
	`address` VARCHAR(200) NOT NULL,
	`url` VARCHAR(200) NULL,
	PRIMARY KEY (`place_id`)
);

CREATE TABLE `schedule` (
	`schedule_id` INT NOT NULL AUTO_INCREMENT,
    `title` VARCHAR(200) NOT NULL,
	`date` DATE NOT NULL,
    `time` VARCHAR(200) NOT NULL,
	`match` INT NULL,
	`equipment` VARCHAR(200) NULL,
    `cost` INT NULL DEFAULT 0,
	`place_id` INT NOT NULL,
	`club_id` INT NOT NULL,
	PRIMARY KEY (`schedule_id`),
	FOREIGN KEY (`club_id`) REFERENCES `club`(`club_id`),
    FOREIGN KEY (`place_id`) REFERENCES `place`(`place_id`)
);



CREATE TABLE `member` (
	`member_id` INT NOT NULL AUTO_INCREMENT,
	`club_id` INT NOT NULL,
	`user_id` INT NOT NULL,
	`position` VARCHAR(200) NOT NULL,
    `current_date` DATE NULL,
	-- `billing_key` VARCHAR(255) NOT NULL,
	PRIMARY KEY (`member_id`),
	FOREIGN KEY (`club_id`) REFERENCES `club`(`club_id`),
	FOREIGN KEY (`user_id`) REFERENCES `user`(`user_id`)
);

CREATE TABLE `participant` (
	`participant_id` INT NOT NULL AUTO_INCREMENT,
	`schedule_id` INT NOT NULL,
	`user_id` INT NOT NULL,
	PRIMARY KEY (`participant_id`),
	FOREIGN KEY (`schedule_id`) REFERENCES `schedule`(`schedule_id`),
	FOREIGN KEY (`user_id`) REFERENCES `user`(`user_id`)
);


CREATE TABLE `receipt` (
	`receipt_id` INT NOT NULL AUTO_INCREMENT,
	`item` VARCHAR(200) NOT NULL,
	`price` INT NOT NULL,
	`schedule_id` INT NOT NULL,
	PRIMARY KEY (`receipt_id`),
	FOREIGN KEY (`schedule_id`) REFERENCES `schedule`(`schedule_id`)
);

CREATE TABLE `payment` (
	`payment_id` INT NOT NULL AUTO_INCREMENT,
    `order_id` VARCHAR(400) NOT NULL,
	`pay_date` TIMESTAMP NOT NULL,
    `price` INT NOT NULL,
	`comment` VARCHAR(200) NOT NULL,
	`club_id` INT NOT NULL,
	`user_id` INT NOT NULL,
	PRIMARY KEY (`payment_id`),
	FOREIGN KEY (`club_id`) REFERENCES `club`(`club_id`),
	FOREIGN KEY (`user_id`) REFERENCES `user`(`user_id`)
);

CREATE TABLE `board` (
	`board_id` INT NOT NULL AUTO_INCREMENT,
	`title` VARCHAR(200) NOT NULL,
	`content` TEXT NOT NULL COMMENT 'placehold',
	`category` VARCHAR(200) NOT NULL COMMENT '공지 - Notice / 일반 - General',
	`date` DATE NOT NULL,
	`user_id` INT NOT NULL,
	`club_id` INT NOT NULL,
	`view_cnt` INT NULL DEFAULT 0,
	`file` VARCHAR(200) NULL,
	PRIMARY KEY (`board_id`),
	FOREIGN KEY (`user_id`) REFERENCES `user`(`user_id`),
	FOREIGN KEY (`club_id`) REFERENCES `club`(`club_id`)
);


-- 클럽 데이터 삽입
INSERT INTO club (name, max_member, content, fee, deadline, logo, account, bank, region, money)
VALUES 
('FC Awesome', 50, 'A great football club', 20000, 10, 'logo1.png', 12345678, 'Bank A', 'Seoul Gangnam-gu', 50000),
('FC Brilliant', 40, 'The most brilliant club', 15000, 15, 'logo2.png', 87654321, 'Bank B', 'Busan Haeundae-gu', 30000),
('FC Champion', 30, 'Champion football club', 10000, 5, 'logo3.png', 11223344, 'Bank C', 'Incheon Namdong-gu', 40000);

-- 유저 데이터 삽입
-- INSERT INTO user (email, password, name, gender, birth, intro)
-- VALUES 
-- ('user1@example.com', 'password1', 'Kim Cheolsoo', 1, '1990-01-01', 'Hello, I am Cheolsoo'),
-- ('user2@example.com', 'password2', 'Lee Younghee', 0, '1992-02-02', 'Hi, I am Younghee'),
-- ('user3@example.com', 'password3', 'Park Jimin', 1, '1994-03-03', 'Hey, I am Jimin');

-- 유저 데이터 삽입
INSERT INTO user (email, password, name, gender, birth, intro, profile)
VALUES 
('user1@example.com', 'password1', 'Kim Cheolsoo', 1, '1990-01-01', 'Hello, I am Cheolsoo', 'profile1.png'),
 ('user2@example.com', 'password2', 'Lee Younghee', 0, '1992-02-02', 'Hi, I am Younghee', 'profile2.png'),
 ('user3@example.com', 'password3', 'Park Jimin', 1, '1994-03-03', 'Hey, I am Jimin', 'profile3.png');

-- 장소 데이터 삽입
INSERT INTO place (name, address, url)
VALUES 
('스카이풋살파크', '서울 영등포구 양평동3가 85', 'https://map.kakao.com/link/map/668122925'),
('천마풋살파크', '서울 송파구 마천동 68-21', 'https://map.kakao.com/link/map/689569518'),
('HK풋살파크', '경기 수원시 권선구 평동 130-1', '	https://map.kakao.com/link/map/1849449239');

-- 스케줄 데이터 삽입
INSERT INTO schedule (title, date, time, `match`, equipment, cost, place_id, club_id)
VALUES 
('Match 1', '2023-05-01', '10:00-12:00', 5, 'Ball, Net', 10000, 1, 1),
('Match 2', '2023-06-10', '14:00-16:00', 7, 'Ball, Net', 20000, 2, 2),
('Match 3', '2023-07-15', '18:00-20:00', 6, 'Ball, Net', 15000, 3, 3);

-- 멤버 데이터 삽입
INSERT INTO member (club_id, user_id, position, `current_date`)
VALUES 
(1, 1, '클럽장', '2023-05-01'),
(2, 2, '클럽원', '2023-06-10'),
(3, 3, '클럽원', '2023-07-15');


-- 참가자 데이터 삽입
INSERT INTO participant (schedule_id, user_id)
VALUES 
(1, 1),
(2, 2),
(3, 3);

-- 영수증 데이터 삽입
INSERT INTO receipt (item, price, schedule_id)
VALUES 
('Water', 5000, 1),
('Snacks', 10000, 2),
('Drinks', 15000, 3);

-- 결제 데이터 삽입
INSERT INTO payment (order_id, pay_date, price, comment, club_id, user_id)
VALUES 
('pay_1', '2024-05-01 10:00:00', 50000, 'Monthly fee', 1, 1),
('pay_2', '2024-06-10 10:00:00', 60000, 'Monthly fee', 2, 2),
('pay_3', '2024-07-15 10:00:00', 70000, 'Monthly fee', 3, 3);

-- 게시판 데이터 삽입
INSERT INTO board (title, content, category, date, user_id, club_id, view_cnt, file)
VALUES 
('Notice 1', 'This is the first notice', 'Notice', '2023-05-01', 1, 1, 10, 'img1.png'),
('General 1', 'This is a general post', 'General', '2023-06-10', 2, 2, 20, 'img2.png'),
('Notice 2', 'This is the second notice', 'Notice', '2023-07-15', 3, 3, 30, 'img3.png');
SELECT * FROM payment;

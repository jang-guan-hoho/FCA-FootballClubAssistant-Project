<template >
    <div>
        <KakaoMap />
    </div>
</template>
<script setup>
    import KakaoMap from '@/components/common/kakao/KakaoMap.vue'
</script>
<style >
    
</style>
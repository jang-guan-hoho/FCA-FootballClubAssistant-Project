<template>
    <div class="navbar">
    <header class="box">
      <nav class="item">
        <!-- <div @click="deleteClub">클럽 삭제</div> -->
        <RouterLink class="nav-item" :to="{name:'ClubUpdate', params:{clubId:route.params.clubId}}">클럽 수정하기</RouterLink>
        <RouterLink class="nav-item" :to="{name:'ClubMember', params:{clubId:route.params.clubId}}">클럽 맴버관리</RouterLink>
        <RouterLink class="nav-item" :to="{name:'ClubFeeManage', params:{clubId:route.params.clubId}}">클럽 회비관리</RouterLink>
      </nav>
    </header>
  </div>
  <RouterView />
</template>

<script setup>

import { useRoute } from 'vue-router';
import { useClubStore } from '@/stores/club';
import { onMounted } from 'vue';
import axios from 'axios';

const accessToken = sessionStorage.getItem('accessToken')
const route = useRoute();
const store = useClubStore();
const deleteClub = function(){
  axios.delete(`http://localhost:8080/fca/club/${route.params.clubId}/manage`,{
    headers:{'accessToken':accessToken}
  })
    .then(() => {
            router.push({ name: 'home' })
        })
}
onMounted(async () => {
  await store.getClub(route.params.clubId); // 클럽 정보를 가져오는 메서드
});
</script>

<style scoped>
h1 {
  font-size: 24p
  x;
}
.navbar {
  background-color: white;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  display: flex;
  justify-content: center;
  margin: 0 auto;
  border-radius: 15px;
  max-width: 1320px; /* 양옆 폭을 줄이기 위해 max-width 설정 */
  opacity : 0.8;
}

.box {
  display: flex;
  justify-content: center;
  width: 100%;
}

.item {
  display: flex;
  justify-content: center;
  padding: 10px 0;
  gap: 10px;
}

.nav-item {
  text-decoration: none;
  color: black;
  font-weight: bold;
}

.router-link-exact-active {
  color: red;
}
</style>
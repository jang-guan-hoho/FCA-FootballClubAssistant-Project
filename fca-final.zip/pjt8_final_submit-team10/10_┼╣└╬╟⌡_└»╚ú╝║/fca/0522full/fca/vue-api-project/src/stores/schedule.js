import { ref, computed } from "vue";
import { defineStore } from "pinia";
import axios from "axios";
import router from "@/router";
import { useLoginStore } from "./login";
import { useClubStore } from "./club";

const REST_CLUB_API = `http://localhost:8080/fca/club`;
// const REST_PLACE_API = `http://localhost:8080/fca/club/${clubId}/place`;
// const REST_PARTICIPANT_API = `http://localhost:8080/fca/club/${clubId}/schedule/${scheduleId}/participant`;
// const REST_SCHEDULE_API = `http://localhost:8080/fca/club/${clubId}/schedule`;
// const REST_RECEIPT_API = `http://localhost:8080/fca/club/${clubId}/schedule/${scheduleId}/receipt`;
const accessToken = sessionStorage.getItem("accessToken");
export const useScheduleStore = defineStore(
  "schedule",
  () => {
    const loginStore = useLoginStore();
    const clubStore = useClubStore();
    const clubId = clubStore.club.clubId;

    const schedule = ref({});
    const scheduleList = ref([]);
    const myScheduleIdList = ref([]);

    const createSchedule = async (clubId, newSchedule) => {
      try {
        const response = await axios.post(
          `http://localhost:8080/fca/club/${clubId}/schedule`,
          newSchedule,
          { headers: { accessToken: accessToken } }
        );
        return response;
      } catch (error) {
        console.error("Error creating schedule:", error);
        throw error;
      }
    };

    const getScheduleList = async function (clubId) {
      console.log("clubId:", clubId);
      if (!clubId) {
        console.error("Invalid clubId:", clubId);
        return;
      }
    
      try {
        const response = await axios.get(`${REST_CLUB_API}/${clubId}/schedule`, {
          headers: { accessToken: accessToken },
        });
        console.log("Response data:", response.data);
        scheduleList.value = response.data.scheduleList;
        myScheduleIdList.value = response.data.myScheduleIdList;
      } catch (err) {
        console.error("Error fetching schedule list:", err);
      }
    };

    const getSchedule = (scheduleId) => {
      console.log("Searching for date:", scheduleId);

      // scheduleList 내 모든 날짜 로깅
      console.log("Available dates in scheduleList:");
      scheduleList.value.forEach((sch) => console.log(sch.date));

      // 일정 찾기
      const foundSchedule = scheduleList.value.find((schedule) => {
        console.log(`Checking ${schedule.scheduleId} against ${scheduleId}`);
        return schedule.scheduleId == scheduleId;
      });

      // 결과 로깅
      if (foundSchedule) {
        console.log("Found schedule:", foundSchedule);
      } else {
        console.log("No schedule found for:", scheduleId);
      }

      schedule.value = foundSchedule;
    };

    // 이제부터 위치정보 출력
    const place = ref({});
    const getScheduleDetail = async (clubId,scheduleId) => {
      try {
        const response = await axios.get(`${REST_CLUB_API}/${clubId}/schedule/${scheduleId}`, {
          headers: { accessToken: accessToken }
        });
        // 서버에서 받은 데이터를 sstore.receipt에 할당
        place.value=response.data.place
        receipt.value = response.data.receiptList;
        participant.value= response.data.participantList
      } catch (error) {
        console.error("Error fetching place data:", error);
      }
    };

    const places = ref([]);

    // 해당 스캐줄의 참여자 유저 아이디 받아오기
    const participant = ref([]);

    function findParticipantId(scheduleId, userId) {
      // participant.value가 배열인지 확인하고, 아니면 배열로 초기화
      if (!Array.isArray(participant.value)) {
        console.error("participant.value는 배열이 아닙니다:", participant.value);
        participant.value = []; // 배열로 초기화
      }
    
      // participants 배열을 순회하여 조건에 맞는 객체를 찾음
      const res = participant.value.find(
        (p) => p.scheduleId === scheduleId && p.userId === userId
      );
    
      // 객체가 존재하면 id를 반환하고, 없으면 null을 반환
      return res ? res.id : null;
    }

    const getParticipant = function (scheduleId) {
      axios
        .get(`${REST_CLUB_API}/${scheduleId}`, {
          headers: { accessToken: accessToken },
        }) // 아마 URL
        .then((response) => {
          participant.value = response.data;
        })
        .catch((err) => {
          console.log(err);
        });

      //테스트 용
      // participant.value = participants.value.filter(participant => participant.scheduleId === scheduleId);
    };

    const receipts = ref([]);
    const receipt = ref([]);
    // const getReceipt = function(scheduleId){
    //   axios.get(`${REST_RECEIPT_API}/${scheduleId}`,
    //   {headers: { 'accessToken':accessToken }})
    //     .then((response) => {
    //     receipt.value = response.data
    //   }).catch((err) => {
    //     console.log(err)
    //   })
    //   // receipt.value = receipts.value.filter(r => r.scheduleId === scheduleId);

    // }

    const createReceipt = function (clubId, scheduleId, rec) {
      axios
        .post(
          `${REST_CLUB_API}/${clubId}/schedule/${scheduleId}/receipt`,
          rec,
          { headers: { accessToken: accessToken } }
        )
        .then((res) => {
          receipt.value = res.data;
          router.push({
            name: "clubScheduleDetail",
            params: { date: schedule.scheduleId },
          });
        });
    };

    const receiptMap = ref({});

    // const getReceiptMap = function (clubId, newDate) {
    //   axios
    //     .get(`${REST_CLUB_API}/${clubId}/receipt/${newDate}`, {
    //       headers: { accessToken: accessToken },
    //     })
    //     .then((response) => {
    //       console.log(response);
    //       const recs = response.data;
    //       console.log(recs);
    //       // Map 객체 초기화
    //       receiptMap.value.clear();
    //       // 데이터를 Map에 저장
    //       recs.forEach((rec) => {
    //         receiptMap.value.set(rec.id, rec);
    //         router.push({
    //           name: "clubScheduleDetailReceipt",
    //           params: { clubId: clubId, receiptDate: newDate },
    //         });
    //       });
    //     })
    //     .catch((err) => {
    //       console.error("Error fetching receipts:", err);
    //     });
    // };

    const getReceiptMap = function (clubId, newDate) {
      axios
        .get(`${REST_CLUB_API}/${clubId}/receipt/${newDate}`, {
          headers: { accessToken: accessToken },
        })
        .then((response) => {
          console.log(response);
          receiptMap.value = response.data;
          // 데이터를 Map에 저장
          router.push({
            name: "clubScheduleDetailReceipt",
            params: { clubId: clubId, receiptDate: newDate },
          });
        })
        .catch((err) => {
          console.error("Error fetching receipts:", err);
        });
    };

    const isScheduleIn = function () {
      getScheduleList(clubId);
      // 클럽 객체가 비어있는지 확인
      return scheduleList.value && Object.keys(scheduleList.value).length > 0;
    };
    return {
      findParticipantId,
      receiptMap,
      getReceiptMap,
      receipts,
      receipt,
      schedule,
      scheduleList,
      createSchedule,
      getSchedule,
      getScheduleList,
      place,
      getScheduleDetail,
      participant,
      getParticipant,
      isScheduleIn,
      createReceipt,
    };
  },
  { persist: true }
);

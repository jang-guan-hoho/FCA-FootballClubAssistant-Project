<template>
  <div class="schedule-detail-container">
    <a class="title">Club Schedule Detail</a>
    <div v-if="sstore.schedule.scheduleId" class="schedule-info">
      <div>
        <h3>오늘 일정</h3>
        <KakaoMap />
        <RouterLink :to="{ name: 'ClubPlaceUpdate', params: { placeId: sstore.schedule.placeId } }" class="btn btn-warning">장소 수정</RouterLink>
        <p>시간: {{ sstore.schedule.time }}</p>
        <p>장비: {{ sstore.schedule.equipment }}</p>
        <p>모집인원: {{ sstore.schedule.match }}명</p>
        <p>현재인원: {{ sstore.participant.length }}명</p>
        <RouterLink :to="{ name: 'ClubScheduleUpdate', params: { scheduleId: sstore.schedule.scheduleId } }" class="btn btn-warning">일정 수정</RouterLink>
      </div>
      <div>
        <button class="btn btn-primary" v-if="!isUserParticipating" @click="joinSchedule">참여 신청</button>
        <button class="btn btn-secondary" v-else @click="cancelSchedule">참여 취소</button>
      </div>
      <div v-for="participant in userList" :key="participant.userId" class="participant">
        <img :src="`http://localhost:8080/resources/${participant.profile}`" alt="이미지" class="participant-img">
        <div>{{ participant.name }}</div>
      </div>
      <button class="btn btn-danger" @click="deleteSchedule">일정 삭제</button>
    </div>
    <table class="receipt-table">
      <thead>
        <tr>
          <th>항목</th>
          <th>금액</th>
      
        </tr>
      </thead>
      <tbody>
        <tr v-for="receipt in receipts" :key="receipt.receiptId">
          <td>{{ receipt.item }}</td>
          <td>{{ receipt.price }}원</td>
          
            <button class="btn btn-danger btn-sm" @click="deleteReceipt(receipt.receiptId)">삭제</button>
          
        </tr>
        
      </tbody>
    </table>
    <h5 style="display: flex; align-self: right">Total: {{ totalAmount }}원</h5>
    <form @submit.prevent="createReceipt" class="receipt-form">
      <input type="text" v-model="receipt.item" placeholder="항목명" required>
      <input type="number" v-model="receipt.price" placeholder="금액" required>
      <button class="btn btn-success" type="submit">추가</button>
    </form>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, computed } from 'vue';
import { useScheduleStore } from '@/stores/schedule';
import KakaoMap from '@/components/common/kakao/KakaoMap.vue';
import { useRoute, useRouter } from 'vue-router';
import { useClubStore } from '@/stores/club';
import { useLoginStore } from '@/stores/login';
import axios from 'axios';

const accessToken = sessionStorage.getItem('accessToken');
const route = useRoute();
const sstore = useScheduleStore();
const cstore = useClubStore();
const lstore = useLoginStore();
const router = useRouter();

const receipt = ref({
  scheduleId: sstore.schedule.scheduleId,
  item: '',
  price: '',
});
const participantId = ref(null);
const userList = ref([]);
const receipts = ref([]);

const createReceipt = async function() {
  await sstore.createReceipt(route.params.clubId, route.params.scheduleId, receipt.value);
  receipts.value = sstore.receipt;
};

const cancelSchedule = async function() {
  try {
    participantId.value = findParticipantId();
    const res = await axios.delete(`http://localhost:8080/fca/club/${route.params.clubId}/schedule/${route.params.scheduleId}/participant/${participantId.value}`, {
      headers: { 'accessToken': accessToken }
    });
    sstore.participant = res.data;
    console.log(sstore.participant);
    await cstore.getUserList(sstore.participant);
    userList.value = cstore.userList;
  } catch (err) {
    console.log(err);
  }
};

function findParticipantId() {
  const loginUser = lstore.loginUser;
  const participant = sstore.participant.find(p => p.userId === loginUser.userId);
  return participant ? participant.participantId : null;
}

const deleteReceipt = async function(receiptId) {
  const res = await axios.delete(`http://localhost:8080/fca/club/${route.params.clubId}/schedule/${route.params.scheduleId}/receipt/${receiptId}`, {
    headers: { 'accessToken': accessToken }
  });
  sstore.receipt = res.data;
  router.push({ name: 'clubScheduleDetail', params: { date: sstore.schedule.date } });
};

async function loadScheduleDetails() {
  try {
    await sstore.getSchedule(route.params.scheduleId);
    console.log("Schedule loaded:", sstore.schedule);

    if (sstore.schedule && sstore.schedule.scheduleId) {
      await sstore.getScheduleDetail(route.params.clubId, route.params.scheduleId);

      console.log(sstore.participant);

      await cstore.getUserList(sstore.participant);
      userList.value = cstore.userList;
    }

    sstore.receipt = [...sstore.receipt];
    
    participantId.value = findParticipantId();
    console.log("participantId: ", participantId.value);
  } catch (error) {
    console.error("Error loading schedule details:", error);
  }
}

onMounted(() => {
  loadScheduleDetails();
});

watch(() => sstore.schedule, (newSchedule) => {
}, { immediate: true });

watch(() => cstore.userList, (newUserList) => {
  userList.value = newUserList;
}, { deep: true });
watch(() => sstore.receipt, (newReceipt) => {
  receipts.value = newReceipt;
  console.log('receipt list updated:', receipts.value);
}, { deep: true });
const joinSchedule = async function() {
  try {
    const res = await axios.post(`http://localhost:8080/fca/club/${route.params.clubId}/schedule/${route.params.scheduleId}/participant`, null, {
      headers: { 'accessToken': accessToken }
    });
    sstore.participant = res.data;
    console.log(sstore.participant);
    await cstore.getUserList(sstore.participant);
    userList.value = cstore.userList;
  } catch (err) {
    console.log(err);
  }
};

const deleteSchedule = async function() {
  try {
    await axios.delete(`http://localhost:8080/api-board/board/${sstore.schedule.scheduleId}`, null, {
      headers: { 'accessToken': accessToken }
    });
    router.push({ name: 'clubScheduleList' });
  } catch (err) {
    console.log(err);
  }
};

const totalAmount = computed(() => {
  return (sstore.receipt || []).reduce((sum, receipt) => sum + receipt.price, 0);
});

const isUserParticipating = computed(() => {
  const loginUser = lstore.loginUser;
  return userList.value.some(participant => participant.userId === loginUser.userId);
});
</script>

<style scoped>
.schedule-detail-container {
  max-width: 800px;
  margin: 0 auto;
  background-color: #fff;
  border-radius: 10px;
  padding: 20px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.title {
  font-size: 24px;
  font-weight: bold;
  text-align: center;
  display: block;
  margin-bottom: 20px;
}

.schedule-info {
  margin-bottom: 20px;
}

.schedule-info h3 {
  font-size: 20px;
  margin-bottom: 10px;
}

.schedule-info p {
  margin-bottom: 5px;
}

.btn {
  margin: 10px;
}

.participant {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.participant-img {
  height: 50px;
  width: 50px;
  border-radius: 50%;
  margin-right: 10px;
}

.receipt-table {
  width: 100%;
  margin-top: 20px;
  border-collapse: collapse;
}

.receipt-table th, .receipt-table td {
  padding: 10px;
  border: 1px solid #ddd;
  text-align: center;
}

.receipt-form {
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
}

.receipt-form input {
  width: 45%;
  padding: 10px;
  margin-right: 10px;
}

.receipt-form button {
  flex-grow: 1;
  padding: 10px;
}
</style>

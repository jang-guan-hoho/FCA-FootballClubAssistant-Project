<template>
  <nav class="navbar navbar-expand-lg ">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item ">
          <RouterLink to="/"><img src="../../assets/img/logo.PNG" alt="logo" height="60px">FootBall Club Assistant</RouterLink> 
        </li> 
        <li class="nav-item">
          <RouterLink :to="{ name: 'clubCreate' }">clubCrete</RouterLink>
        </li>
        <li class="nav-item">
          <RouterLink :to="{ name: 'club' }">clubHome</RouterLink>
        </li>
      </ul>
      <RouterLink class="nav-item" v-if="loginStore.accessToken === ''" to="/login"
        >Login</RouterLink>
      <a class="nav-item" v-else @click="logout">Logout</a> 
      <RouterLink class="nav-item" v-if="loginStore.accessToken === ''" :to="{ name: 'signUp' }">회원가입</RouterLink>
      <RouterLink class="nav-item" v-else :to="{ name: 'myPage' }">마이페이지</RouterLink>
    </div>
  </div>
</nav>

</template>

<script setup>
import { useClubStore } from "@/stores/club";
import { useLoginStore } from "@/stores/login";
import { onMounted, ref, computed } from "vue";
const loginStore = useLoginStore();
const hasAccessToken = computed(() => {
  return sessionStorage.getItem("accessToken");
});
const logout = () => {
  loginStore.logout();
};
</script>

<style scoped>
#container {
  text-align: center;
}

nav a {
  font-weight: bold;
  text-decoration: none;
  color: black;
}
.nav-item{
 margin-left: 20px;
 margin-right: 20px;

 font-size: 20px;
}
.nav-item:hover{
color: #42b983;
}
.nav-item>a:hover{
  color:#42b983;
}
.navbar-nav{
  display: flex;
  align-items: center;
  justify-content: left;
}
nav a.router-link-exact-active {
  color: #43da96;
}
</style>

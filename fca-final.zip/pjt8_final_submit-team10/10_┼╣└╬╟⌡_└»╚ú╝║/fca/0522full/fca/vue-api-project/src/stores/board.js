import { ref, computed } from "vue";
import { defineStore } from "pinia";
import axios from "axios";
import router from "@/router";
import { useLoginStore } from "./login";
import { useClubStore } from "./club";

const REST_CLUB_API = `http://localhost:8080/fca/club`;
export const useBoardStore = defineStore(
  "board",
  () => {
    const loginStore = useLoginStore();
    const board = ref({});
    const boardList = ref([]);
    const clubStore = useClubStore();
    const accessToken = sessionStorage.getItem("accessToken");

    const createBoard = function (formData) {
      // const formData = new FormData();
      // Object.keys(boardData).forEach((key) => {
      //   if (boardData[key] instanceof File) {
      //     formData.append(key, boardData[key], boardData[key].name);
      //   } else {
      //     formData.append(key, boardData[key]);
      //   }
      return axios({
        url: `${REST_CLUB_API}/${clubStore.club.clubId}/board`,
        method: "POST",
        data: formData,
        headers: {
          "Content-Type": "multipart/form-data",
          accessToken: accessToken,
        },
      })
        .then((response) => {
          board.value = response.data;
          router.push({
            name: "boardDetail",
            params: { boardId: board.value.boardId },
          });
        })
        .catch((err) => {
          console.error("Error creating board:", err);
        });
    };

    const getBoardList = function () {
      axios
        .get(`${REST_CLUB_API}/${clubStore.club.clubId}/board`, {
          headers: { accessToken: accessToken },
        })
        .then((response) => {
          console.log(response.data);
          boardList.value = response.data;
        });
    };

    const getBoard = function (boardId) {
      axios
        .get(`${REST_CLUB_API}/${clubStore.club.clubId}/board/${boardId}`, {
          headers: { accessToken: accessToken },
        })
        .then((response) => {
          board.value = response.data;
        });
    };

    const searchBoardList = function (searchCondition) {
      axios
        .get(`${REST_CLUB_API}/${clubStore.club.clubId}/board`, {
          params: searchCondition,
          headers: { accessToken: accessToken },
        })
        .then((res) => {
          boardList.value = res.data;
        });
    };

    return {
      createBoard,
      boardList,
      getBoardList,
      board,
      getBoard,
      searchBoardList,
    };
  },
  { persist: true }
);

<template>
  <div>

    <RouterLink class="btn btn-success" :to="{ name: 'placeCreate', params: { clubId: clubId } }">일정 생성</RouterLink>
    
    <!-- 캘린더 삽입 -->
    <FullCalendar class="calendar" :options="calendarOptions" />
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from "vue";
import FullCalendar from "@fullcalendar/vue3";
import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";
import { useRoute, useRouter } from "vue-router";
import { useClubStore } from "@/stores/club";
import { useScheduleStore } from "@/stores/schedule";

const cstore = useClubStore();
const sstore = useScheduleStore();
const router = useRouter();
const route = useRoute();
const clubId = ref(route.params.clubId);

const calendarOptions = ref({
  plugins: [dayGridPlugin, interactionPlugin],
  initialView: "dayGridMonth",
  events: [],
  dateClick: handleDateClick,
});

function handleDateClick(info) {
  console.log("클릭한 날짜:", info.dateStr);

  if (event.value && event.value.length > 0) {
    function formatDateToYYYYMMDD(dateStr) {
      const date = new Date(dateStr);
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    }

    const clickedDate = formatDateToYYYYMMDD(info.dateStr);

    console.log("일정 목록:", event.value);

    const hasEventOnDate = event.value.some(
      (schedule) => formatDateToYYYYMMDD(schedule.date) === clickedDate
    );

    if (hasEventOnDate) {
      const schedule = event.value.find(
        (schedule) => formatDateToYYYYMMDD(schedule.date) === clickedDate
      );
      router.push({
        name: "clubScheduleDetail",
        params: { scheduleId: schedule.scheduleId },
      });
    } else {
      alert("선택한 날짜에 일정이 없습니다.");
    }
  } else {
    console.log("일정 데이터가 아직 로드되지 않았습니다.");
  }
}

const event = ref([]);

onMounted(() => {
  console.log(route.params.clubId);
  sstore.getScheduleList(route.params.clubId);
});

watch(
  () => sstore.scheduleList,
  (newScheduleList) => {
    event.value = newScheduleList;
    calendarOptions.value.events = event.value;
    console.log("캘린더 이벤트가 업데이트되었습니다:", event.value);
  },
  { immediate: true }
);
</script>

<style scoped>
.btn{
  position: absolute;
  left: 550px;
  top: 49%
}
.calendar{
  padding-top: 20px;
}
</style>

<template>
    <div>
      <h4>게시글 등록</h4>
      <form @submit.prevent="createBoard">
        <fieldset>
          <legend>게시글 정보 입력</legend>
          <div>
            <label for="title">제목:</label>
            <input type="text" id="title" v-model="newBoard.title" required />
          </div>
          <div>
            <label for="content">내용:</label>
            <textarea
              id="content"
              cols="30"
              rows="10"
              v-model="newBoard.content"
              required
            ></textarea>
          </div>
          <div>
            <label for="category">카테고리:</label>
            <select id="category" v-model="newBoard.category">
              <option value="true">일반글</option>
              <option value="false">공지</option>
            </select>
          </div>
          <div>
            <label for="image">이미지 업로드:</label>
            <input type="file" id="image" @change="handleProfileUpload" />
            <img
              :src="profilePreview"
              alt="Profile Picture"
              v-if="profilePreview"
            />
          </div>
          <!-- <div>
                      <label for="video">비디오 업로드:</label>
                      <input type="file" id="video" ref="videoInput" @change="handleVideoChange">
                  </div> -->
          <button type="submit">등록</button>
        </fieldset>
      </form>
    </div>
  </template>
  
  <script setup>
  import { ref } from "vue";
  import { useBoardStore } from "@/stores/board";
  import { useLoginStore } from "@/stores/login";
  import { useClubStore } from "@/stores/club";
  
  const cstore = useClubStore();
  const ustore = useLoginStore();
  const bstore = useBoardStore();
  const profilePreview = ref(null);
  const newFile = ref(null);
  const newBoard = ref({
    title: "",
    userId: `${ustore.loginUser.userId}`,
    clubId: `${cstore.club.clubId}`,
    content: "",
    category: "true", // 기본값을 'true'로 설정하여 공개 게시글로 초기화
    viewCnt: 0, // 초기 조회수는 0
  });
  
  const imageInput = ref(null);
  const videoInput = ref(null);
  
  const handleProfileUpload = (event) => {
    const file = event.target.files[0];
    console.log(file);
    if (file) {
      newFile.value = file;
      profilePreview.value = URL.createObjectURL(file);
    }
  };
  
  const createBoard = async () => {
    const formData = new FormData();
    formData.append(
      "board",
      new Blob([JSON.stringify(newBoard.value)], { type: "application/json" })
    );
  
    if (newFile.value instanceof File) {
      formData.append("file", newFile.value);
    }
  
    await bstore.createBoard(formData);
  };
  </script>
  
  <style scoped>
  fieldset {
    margin-top: 20px;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
  }
  label {
    display: block;
    margin-bottom: 10px;
  }
  input[type="text"],
  input[type="file"],
  textarea,
  select {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
  }
  button {
    margin-top: 20px;
    padding: 10px 20px;
    cursor: pointer;
  }
  </style>
  
<template>
    <div>
      <h4>장소 수정</h4>
      <KakaoMap />
      <form @submit.prevent="updatePlace">
        <fieldset>
          <legend>장소 정보 수정</legend>
          <div>
            <label for="placeName">장소 이름:</label>
            <input type="text" id="placeName" v-model="place.name" required>
          </div>
          <div>
            <label for="address">주소:</label>
            <input type="text" id="address" v-model="place.address" required>
          </div>
          <div>
            <label for="url">URL:</label>
            <input type="text" id="url" v-model="place.url" required>
          </div>
          <button type="submit">수정</button>
        </fieldset>
      </form>
    </div>
  </template>
  
  <script setup>
  import { ref, onMounted } from 'vue';
  import { useRoute, useRouter } from 'vue-router';
  import axios from 'axios';
  import KakaoMap from '@/components/common/kakao/KakaoMap.vue';
import { useScheduleStore } from '@/stores/schedule';
  
const accessToken = sessionStorage.getItem('accessToken');
  const place = ref({
    name: '',
    address: '',
    url: '',
  });
  
  const router = useRouter();
  const route = useRoute();
  const store =useScheduleStore()

  const loadPlaceDetails = async () => {
    place.value = store.place;
  };
  
  const updatePlace = async () => {
    try {
      await axios.put(`http://localhost:8080/fca/club/${route.params.clubId}/place/${route.params.placeId}`, place.value,{
        headers:{'accessToken':accessToken}
      });
      console.log('장소 수정 완료');
      // 장소 수정 후 스케줄 생성 페이지로 이동
      router.push({ name: 'scheduleList', params: { clubId: route.params.clubId } });
    } catch (error) {
      console.error('장소 수정 중 오류 발생:', error);
    }
  };
  
  onMounted(() => {
    loadPlaceDetails();
  });
  </script>
  
  <style scoped>
  fieldset {
    margin-top: 20px;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
  }
  label {
    display: block;
    margin-bottom: 10px;
  }
  input[type="text"] {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
  }
  button {
    margin-top: 20px;
    padding: 10px 20px;
    cursor: pointer;
  }
  </style>
  
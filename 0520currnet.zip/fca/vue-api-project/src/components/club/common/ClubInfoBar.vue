<template>
  <div>
    <div>{{ store.club.clubImg }}</div>
    <div>{{ store.club.name }}</div>
    <div>{{ store.club.content }}</div>
    <button @click="openModal">
      회비 결제
    </button>

    <!-- 모달 구조 -->
    <div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="paymentModalLabel">회비 결제</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <CheckoutView :clubId="store.club.clubId" :clubFee="clubFee" :clubName="store.club.name" />
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useClubStore } from '@/stores/club';
import { onMounted, ref, watch } from 'vue';
import * as bootstrap from 'bootstrap';
import CheckoutView from '@/views/CheckoutView.vue';

const store = useClubStore();
const clubFee = ref(1000); // 초기 값 설정

const openModal = () => {
  // clubFee 값이 제대로 설정되었는지 확인
  console.log('Opening modal with club fee:', clubFee.value);
  const paymentModal = new bootstrap.Modal(document.getElementById('paymentModal'));
  paymentModal.show();
};

onMounted(() => {
  // clubFee가 업데이트 될 때마다 로그를 출력
  watch(() => store.club.fee, (newFee) => {
    console.log('Updated club fee:', newFee);
    clubFee.value = newFee;
  }, { immediate: true }); // 초기 값 설정을 위해 immediate: true 옵션 사용
});
</script>

<style scoped>
#container {
  text-align: center;
  border-radius: 45%;
}
</style>

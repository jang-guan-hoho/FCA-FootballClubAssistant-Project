import { ref } from 'vue';
import { defineStore } from 'pinia';
import axios from 'axios';
import router from '@/router';
import { useLoginStore } from './login';

const REST_CLUB_API = 'http://localhost:8080/fca/club';
const REST_CLUB_MEMBER_API = 'http://localhost:8080/fca/clubMember';

const loginStore = useLoginStore();
const accessToken = sessionStorage.getItem('accessToken');
export const useClubStore = defineStore('club', () => {
  const clubList = ref([
    {
      clubId: 2,
      name: 'ssafy',
      maxMember: 10,
      fee: 100000,
      deadline: 15,
      bank: '기업',
    },
    {
      clubId: 1,
      name: 's',
      maxMember: 10,
      fee: 10000,
      deadline: 15,
      bank: '우리',
    },
  ]);
  const MyClubIdList = ref([1]);
  const MyClubList = ref([]);
  const club = ref({});
  const clubMember = ref([
    // 더미 데이터
    {
      userId: 1,
      name: '김철수',
      profile: 'https://example.com/profiles/kim.jpg',
      currentDate:'2024-05-21',
    },
    {
      userId: 2,
      name: '이영희',
      profile: 'https://example.com/profiles/lee.jpg',
      currentDate:'2024-05-20',

    },
    {
      userId: 3,
      name: '박지민',
      profile: 'https://example.com/profiles/park.jpg',
      currentDate:'2024-05-19',

    },
  ]);

  const createClub = function (club) {
    const formData = new FormData();
    formData.append('name', club.name);
    formData.append('maxMember', club.maxMember);
    formData.append('fee', club.fee);
    formData.append('deadline', club.deadline);
    formData.append('bank', club.bank);
    formData.append('content', club.content);
    formData.append('account', club.account);
    formData.append('region', club.region);
    if (club.clubImg) {
      formData.append('clubImg', club.clubImg);
    }
    if (club.logo) {
      formData.append('logo', club.logo);
    }

    axios({
      url: REST_CLUB_API,
      method: 'POST',
      data: formData,
      headers: {
        'Content-Type': 'multipart/form-data',
        'accessToken':accessToken 
      }
    })
      .then(() => {
        router.push({ name: 'clubHome' });
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const getClubMember = function (clubId) {
    axios.get(`${REST_CLUB_API}/${clubId}`,{
      headers: { 'accessToken':accessToken }
    })
      .then((response) => {
        clubMember.value = response.data;
      });
  };

  const getClub = function (clubId) {
    axios.get(`${REST_CLUB_API}/${clubId}`,{
      headers: { 'accessToken':accessToken }
    })
    .then((response)=>{
      club.value = response.data;
    })
  };

  const updateClub = async function (formData) {
    try {
      const response = await axios.put(`${REST_CLUB_API}/${formData.get('clubId')}/manage`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
          ,'accessToken':accessToken 
        }
      });
      this.club = response.data;
      return response.data;
    } catch (error) {
      console.error('클럽 업데이트 중 오류 발생:', error);
      throw error;
    }
  };

  const userList = ref([]);
  const getUserList = function (userIds) {
    const foundUser = clubMember.value.find((user) => user.userId === userIds);
    console.log(foundUser);

    if (foundUser) {
      userList.value.push(foundUser);
    } else {
      console.log('No user found with ID:', userIds);
    }
  };

  const getClubList = function () {
    axios.get("http://localhost:8080/fca",
    {headers: { 'accessToken':loginStore.accessToken }})
      .then((response) => {
        clubList.value = response.data;
      });
  };

  const getMyClubList = function (userId) {
    axios.get(`${REST_CLUB_MEMBER_API}/${userId}`,{
      headers: { 'accessToken':loginStore.accessToken }
    })
      .then((response) => {
        MyClubList.value = response.data;
      });
  };

  const updateMyClubList = function () {
    MyClubList.value = [];
    MyClubIdList.value.forEach((clubId) => {
      const club = clubList.value.find((c) => c.clubId === clubId);
      if (club) {
        MyClubList.value.push(club);
      }
    });
  };

  const joinClub = function (clubId, user) {
    axios.post(`${REST_CLUB_API}/${clubId}/join`, user,
     {headers: { 'accessToken':loginStore.accessToken }})
      .then(() => {
        router.push({ name: 'clubHome', params: { clubId: clubId } });
      });
  };

  const createPayment = function (payment, clubId) {
    console.log(payment);
    console.log(clubId);
     axios.post(`${REST_CLUB_API}/${clubId}/payment`, payment,
     {headers: { 'accessToken':accessToken }})
     .then(()=>{
       alert('결제 성공')
      router.push({name:'clubHome', params:{clubId:clubId}})
     })
    alert('결제 성공');
    // router.push({ name: 'clubHome', params: { clubId: clubId } });
  };

  const isClubIn = function () {
    updateMyClubList();
    return MyClubList.value && Object.keys(MyClubList.value).length > 0;
  };

  return {
    createPayment,
    joinClub,
    createClub,
    clubMember,
    getClubMember,
    club,
    updateClub,
    userList,
    getUserList,
    clubList,
    isClubIn,
    getClubList,
    MyClubIdList,
    MyClubList,
    getMyClubList,
    updateMyClubList,
    getClub
  };
});

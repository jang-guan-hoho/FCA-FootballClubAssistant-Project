<template>
  <div>
    <a>Club Schedule</a>
    <RouterView />

    </div>
</template>

<script setup>



</script>

<style scoped>
</style>


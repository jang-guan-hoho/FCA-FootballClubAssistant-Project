package com.fca.model.dao;

import com.fca.model.dto.User;

public interface UserDao {

	User loginUser(User user);
}

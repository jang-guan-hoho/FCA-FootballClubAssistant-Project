package com.fca.model.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.fca.model.dto.Club;
import com.fca.model.dto.Participant;
import com.fca.model.dto.Place;
import com.fca.model.dto.Receipt;
import com.fca.model.dto.Schedule;

public interface ScheduleDao {

	List<Schedule> selectScheduleList(int clubId);

	List<Integer> selectMyScheduleIdList(Map<String, Object> paramMap);

	int insertSchedule(Schedule schedule);
	
	Place selectPlace(int scheduleId);
	
	List<Receipt> selectReceipt(int scheduleId);
	
	List<Participant> selectParticipant(int scheduleId);
	
	int updatePlace(Place place);

	int updateSchedule(Schedule schedule);

	int deleteSchedule(int scheduleId);

	int insertParticipant(Map<String, Object> paramMap);
	
	Date selectCurrentDate(int scheduleId);
	
	int updateMemberCurrentDate(Map<String, Object> paramMap);

	int deleteParticipant(int participantId);

	int insertReceipt(Receipt receipt);

	int deleteReceipt(int receiptId);

	int insertPlace(Place place);

	Place selectNewPlace();
}

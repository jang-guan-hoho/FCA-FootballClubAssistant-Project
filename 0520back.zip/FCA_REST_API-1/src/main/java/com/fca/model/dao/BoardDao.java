package com.fca.model.dao;

import java.util.List;

import com.fca.model.dto.Board;
import com.fca.model.dto.SearchCondition;

public interface BoardDao {

	List<Board> selectBoardList(SearchCondition searchCondition);

	void updateViewCnt(int boardId);

	Board selectBoardDetail(int boardId);

	int insertBoard(Board board);

	int deleteBoard(int id);

	int updateBoard(Board board);
}

package com.fca.model.service;

import com.fca.model.dto.User;

public interface UserService {

	User loginUser(User user);
}

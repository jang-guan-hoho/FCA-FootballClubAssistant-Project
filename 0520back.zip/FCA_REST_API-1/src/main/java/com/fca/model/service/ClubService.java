package com.fca.model.service;

import java.util.List;
import java.util.Map;

import com.fca.model.dto.Club;
import com.fca.model.dto.Member;
import com.fca.model.dto.Payment;
import com.fca.model.dto.User;

public interface ClubService {

	List<Club> getclubList();

	Club getClub(int clubId);

	List<Map<String, Object>> getMemberList(int clubId);

	int joinClub(int clubId, int userId);

	int createClub(Club club, int userId);

	Club getNewClub();

	int deleteMember(int memberId);

	int updateMember(Member member);

	int updateClub(Club club);

	int deleteClub(int clubId);

	Map<String, Object> getClubReceipt(int clubId, int year, int month);

	Map<String, Object> getPaymentList(int clubId, int year, int month);

	int createPayment(Payment payment);
}

package com.fca.model.dao;

import java.util.List;
import java.util.Map;

import com.fca.model.dto.Club;
import com.fca.model.dto.Member;
import com.fca.model.dto.Payment;
import com.fca.model.dto.Schedule;

public interface ClubDao {

	List<Club> selectClubAll();

	Club selectClub(int clubId);

	List<Map<String, Object>> selectMembers(int clubId);

	int insertMember(Map<String, Object> map);

	int insertClub(Club club);

	Club selectNewClub();

	int deleteMember(int memberId);

	int updateMember(Member member);

	int updateClub(Club club);

	int deleteClub(int clubId);

	int selectPayments(Map<String, Object> paramMap);

	int selectCosts(Map<String, Object> paramMap);

	List<Map<String, Object>> selectDateCosts(Map<String, Object> paramMap);
	
	List<Map<String, Object>> selectDateReceipts(Map<String, Object> paramMap);

	List<Payment> selectDatePayments(Map<String, Object> paramMap);

	int insertPayment(Payment payment);
}

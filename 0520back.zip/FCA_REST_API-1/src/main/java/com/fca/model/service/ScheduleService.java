package com.fca.model.service;

import java.util.List;
import java.util.Map;

import com.fca.model.dto.Club;
import com.fca.model.dto.Participant;
import com.fca.model.dto.Place;
import com.fca.model.dto.Receipt;
import com.fca.model.dto.Schedule;

public interface ScheduleService {

	Map<String, Object> getScheduleIdList(int clubId, int userId);
	
	int createPlace(Place place);
	
	Place getNewPlace();

	int createClubSchedule(Schedule schedule);
	
	Map<String, Object> getScheduleDetail(int scheduleId);
	
	int updatePlace(Place place);

	int updateSchedule(Schedule schedule);

	int deleteSchedule(int scheduleId);

	int createParticipant(int scheduleId, int clubId, int userId);

	int deleteParticipant(int participantId);

	int createReceipt(Receipt receipt);

	int deleteReceipt(int receiptId);

	List<Participant> getParticipantList(int scheduleId);

	List<Receipt> getreceiptList(int scheduleId);
}

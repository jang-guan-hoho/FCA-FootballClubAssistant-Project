package com.fca.model.service;

import java.util.List;

import com.fca.model.dto.Board;
import com.fca.model.dto.SearchCondition;

public interface BoardService {

	List<Board> getBoardList(SearchCondition condition);

	Board getBoardDetail(int boardId);

	boolean createBoard(Board board);

	boolean modifyBoard(Board board);

	boolean removeBoard(int boardId);
}

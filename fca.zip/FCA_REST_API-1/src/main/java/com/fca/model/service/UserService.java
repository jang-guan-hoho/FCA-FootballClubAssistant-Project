package com.fca.model.service;

import com.fca.model.dto.User;

public interface UserService {

	User loginUser(User user);

	int createUser(User user);

	int updateUser(User user);

	int deleteUser(int userId);
}

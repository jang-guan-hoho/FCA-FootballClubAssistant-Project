package com.fca.controller;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fca.annotation.AuthRequired;
import com.fca.model.dto.User;
import com.fca.model.service.UserService;
import com.fca.util.JwtUtil;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/fca")
@Tag(name = "UserRestController", description = "User CRUD")
public class UserRestController {
    
    private UserService userService;
    
    private JwtUtil jwtUtil;
    
    private ResourceLoader resLoader;
    
    @Autowired
    public UserRestController(UserService userService, JwtUtil jwtUtil, ResourceLoader resLoader) {
        this.userService = userService;
        this.jwtUtil = jwtUtil;
        this.resLoader = resLoader;
    }
    
    @Value("${jwt.refreshtoken.expiretime}")
    private int refreshTokenExpireTime;
    
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user, HttpServletResponse response) throws UnsupportedEncodingException{
        
        Map<String, Object> result = new HashMap<>();
        
        // DB에서 유저 가져오기
        User dbUser = userService.loginUser(user);
        
        // 일치하는 유저가 없다면 UNAUTHORIZED 반환.
        if(dbUser == null) {
            result.put("message", "일치하는 유저가 없습니다.");
            return new ResponseEntity<Map<String, Object>>(result, HttpStatus.UNAUTHORIZED);
        }
        
        // 있으면 Token 발급
        // AccessToken, RefreshToken 두 개를 발급해준다.
        String accessToken = jwtUtil.createAccessToken(dbUser.getUserId());
        String refreshToken = jwtUtil.createRefreshToken(dbUser.getUserId());
        
        // refreshtoken은 처음 발급할 때 -> DB에 저장.
        // INSERT INTO `refresh-token` (userId, refreshToken)  VALUE (#{userId}, #{refreshToken}) 
        
        Cookie cookie = new Cookie("refreshToken", refreshToken);
        cookie.setMaxAge(refreshTokenExpireTime);
        cookie.setHttpOnly(true);
        cookie.setPath("/");
        response.addCookie(cookie);
        
        result.put("accessToken", accessToken);
        result.put("loginUser", dbUser);
        
        return new ResponseEntity<>(result, HttpStatus.ACCEPTED);
    }
    
    @GetMapping("/refresh")
    ResponseEntity<?> refreshToken(){
        return null;
    }
    
    @PostMapping("/sign-up")
    public ResponseEntity<?> doSignUp(@RequestPart("user") User user, @RequestPart(value = "profile", required = false) MultipartFile file) throws IOException{
        handleFileUpload(user, file);
        int result = userService.createUser(user);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
    
    @AuthRequired
    @PutMapping("/my-page")
    public ResponseEntity<?> updateUser(HttpServletRequest request, @RequestPart("user") User user, @RequestPart(value = "profile", required = false) MultipartFile file) throws ParseException, IOException{
        String accessToken = request.getHeader("accessToken");
        int userId = jwtUtil.getUserId(accessToken);
        user.setUserId(userId);
        
        handleFileUpload(user, file);
        
        int result = userService.updateUser(user);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
    
    @AuthRequired
    @DeleteMapping("/my-page")
    public ResponseEntity<?> deleteUser(HttpServletRequest request) throws ParseException{
        String accessToken = request.getHeader("accessToken");
        int userId = jwtUtil.getUserId(accessToken);
        int result = userService.deleteUser(userId);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    private void handleFileUpload(User user, MultipartFile file) throws IOException {
        if (file != null && !file.isEmpty()) {
            // 파일을 저장할 폴더 지정 (프로젝트의 절대 경로)
            String uploadDir = System.getProperty("user.dir") + "/src/main/resources/static/resources/";
            Path uploadPath = Paths.get(uploadDir);
            
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }
            
            String fileName = System.currentTimeMillis() + "_" + StringUtils.cleanPath(file.getOriginalFilename());
            Path filePath = uploadPath.resolve(fileName);
            Files.copy(file.getInputStream(), filePath);
            
            user.setProfile(fileName);
            user.setOrgProfile(file.getOriginalFilename());
        }
    }
}
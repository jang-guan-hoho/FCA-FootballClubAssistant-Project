package com.fca.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fca.annotation.AuthRequired;
import com.fca.model.dto.Club;
import com.fca.model.dto.Member;
import com.fca.model.dto.Payment;
import com.fca.model.dto.Receipt;
import com.fca.model.dto.User;
import com.fca.model.service.ClubService;
import com.fca.model.service.ClubServiceImpl;
import com.fca.util.JwtUtil;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/fca")
@Tag(name = "ClubRestController", description = "Club CRUD")
public class ClubRestController {
	
	private ClubService clubService;
	
	private JwtUtil jwtUtil;
	
	@Autowired
	public ClubRestController(ClubService clubService, JwtUtil jwtUtil) {
		this.clubService = clubService;
		this.jwtUtil = jwtUtil;
	}
	
	// 홈페이지로 이동
    @GetMapping("")
    public ResponseEntity<?> goHome(){
    	List<Club> clubList = clubService.getclubList();
        return new ResponseEntity<>(clubList, HttpStatus.OK);
    }
    
    // 클럽 홈으로 이동
    @GetMapping("/club/{clubId}")
    public ResponseEntity<?> goClubDetail(@PathVariable("clubId") int clubId){
    	System.out.println(clubId);
    	Club club = clubService.getClub(clubId);
    	List<Map<String, Object>> memberList = clubService.getMemberList(clubId);
    	Map<String, Object> responseData = new HashMap<>();
        responseData.put("club", club);
        responseData.put("memberList", memberList);
        return new ResponseEntity<>(responseData, HttpStatus.OK);
    }
    
    // 내가 가입한 클럽
    @AuthRequired
    @GetMapping("/club/myClub")
    public ResponseEntity<?> gomyClubList(HttpServletRequest request) throws ParseException{
    	String accessToken = request.getHeader("accessToken");
    	int userId = jwtUtil.getUserId(accessToken);
    	List<Club> myClubList = clubService.getMyClubList(userId);
    	return new ResponseEntity<>(myClubList, HttpStatus.OK);
    }
    
    // 클럽 가입 폼으로 이동
//    @GetMapping("/club/{clubid}/join")
//    public ResponseEntity<?> goClubJoinForm(){
//        return new ResponseEntity<Void>(HttpStatus.OK);
//    }
    
    // 클럽 가입 실행
    @AuthRequired
    @PostMapping("/club/{clubId}/join")
    public ResponseEntity<?> doClubJoin(@PathVariable("clubId") int clubId, HttpServletRequest request) throws ParseException{
    	String accessToken = request.getHeader("accessToken");
		int userId = jwtUtil.getUserId(accessToken);
    	int result = clubService.joinClub(clubId, userId, "클럽원");
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
    
    // 클럽 내정보 수정 -> 내가 참여한 일정 -> 일정 홈에 같이 보여주는 식이 좋을듯?
//    @GetMapping("/club/{clubid}")
//    public ResponseEntity<?> goClubMyInfo(int userId){
//    	List<Integer> scheduleIdList = clubService.getUserSchedule(userId);
//        return new ResponseEntity<>(scheduleIdList, HttpStatus.OK);
//    }
    
    // 회비내역 -> 개어려움 생각 좀 정리하고 할 것
    @AuthRequired
    @GetMapping("/club/{clubId}/receipt/{newDate}")
    public ResponseEntity<?> goClubReceipt(@PathVariable("clubId") int clubId, @PathVariable("newDate") String newDate){
    	String[] dateArr = newDate.split("-");
    	int year = Integer.parseInt(dateArr[0]);
    	int month = Integer.parseInt(dateArr[1]);
    	Map<String, Object> receiptMap = clubService.getClubReceipt(clubId, year, month);
        return new ResponseEntity<>(receiptMap, HttpStatus.OK);
    }
    
    // 클럽 생성폼 이동
//    @GetMapping("/club")
//    public ResponseEntity<?> goClubForm(){
//        return new ResponseEntity<Void>(HttpStatus.OK);
//    }
    
    // 클럽 생성 --> 파일로 받는 애들 어떻게 처리해야되는지 확인해야함
    @AuthRequired
    @PostMapping("/club")
    public ResponseEntity<?> clubCreate(@RequestPart("club") Club club, @RequestPart(value = "logo", required = false) MultipartFile file, HttpServletRequest request) throws ParseException, IOException{
    	handleFileUpload(club, file);
    	String accessToken = request.getHeader("accessToken");
		int userId = jwtUtil.getUserId(accessToken);
    	clubService.createClub(club, userId); // Club 컬럼 생성하면서 동시에 Member 컬럼(클럽장)도 생성해야함
    	Club newClub = clubService.getNewClub(); // 방금 생성한 클럽 정보 가져와야함
    	clubService.joinClub(newClub.getClubId(), userId, "클럽장");
        return new ResponseEntity<>(newClub, HttpStatus.OK);
    }
    
    // 클럽 관리 이동
//    @GetMapping("/club/{id}/manage")
//    public ResponseEntity<?> goClubManage(){
//        return new ResponseEntity<Void>(HttpStatus.OK);
//    }
    
    // 클럽원 관리 이동 -> pinia에서 꺼내서 사용?
//    @GetMapping("/club/{clubId}/manage/member")
//    public ResponseEntity<?> goClubManageMember(){
//        return new ResponseEntity<Void>(HttpStatus.OK);
//    }
    
    // 클럽원 삭제
    @AuthRequired
    @DeleteMapping("/club/{clubId}/manage/{memberId}")
    public ResponseEntity<?> clubManageMemberDelete(@PathVariable("memberId") int memberId){
    	int result = clubService.deleteMember(memberId);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
    
    // 클럽원 수정 -> front에서 넘길 때 객체 정보 전부 넘겨야함
    @AuthRequired
    @PutMapping("/club/{clubId}/manage/{memberId}")
    public ResponseEntity<?> clubManageMemberUpdate(@PathVariable("memberId") int memberId, @RequestBody Member member){
    	member.setMemberId(memberId);
    	int result = clubService.updateMember(member);    	
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
    
    //클럽 수정 --> 파일로 받는 애들 어떻게 처리해야되는지 확인해야함
    @AuthRequired
    @PutMapping("/club/{clubId}/manage")
    public ResponseEntity<?> clubManageUpdate(@PathVariable("clubId") int clubId, @RequestBody Club club){
    	club.setClubId(clubId);
    	int result = clubService.updateClub(club);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
    
    //클럽 삭제
    @AuthRequired
    @DeleteMapping("/club/{clubId}/manage")
    public ResponseEntity<?> clubManageDelete(@PathVariable("clubId") int clubId){
    	int result = clubService.deleteClub(clubId);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
    
    //클럽 회비 관리 -> 어떤 데이터가 필요한지 좀 더 생각해보자..
    @AuthRequired
    @GetMapping("/club/{clubId}/manage/receipt/{newDate}")
    public ResponseEntity<?> goClubManageReceipt(@PathVariable("clubId") int clubId, @PathVariable("newDate") String newDate){
    	String[] dateArr = newDate.split("-");
    	int year = Integer.parseInt(dateArr[0]);
    	int month = Integer.parseInt(dateArr[1]);
    	Map<String, Object> paymentList = clubService.getPaymentList(clubId, year, month);
        return new ResponseEntity<>(paymentList, HttpStatus.OK);
    }
    
    // 클럽 회비 결제
    @AuthRequired
    @PostMapping("/club/{clubId}/payment")
    public ResponseEntity<?> paymentCreate(@RequestBody Payment payment, @PathVariable("clubId") int clubId, HttpServletRequest request) throws ParseException{
    	String accessToken = request.getHeader("accessToken");
		int userId = jwtUtil.getUserId(accessToken);
    	payment.setClubId(clubId);
    	payment.setUserId(userId);
    	int result = clubService.createPayment(payment);
    	List<Payment> payments = clubService.getPayments(clubId);
        return new ResponseEntity<>(payments, HttpStatus.OK);
    }
    
    private void handleFileUpload(Club club, MultipartFile file) throws IOException {
    	if (file != null && !file.isEmpty()) {
    		// 파일을 저장할 폴더 지정 (프로젝트의 절대 경로)
    		String uploadDir = System.getProperty("user.dir") + "/src/main/resources/static/resources/";
    		Path uploadPath = Paths.get(uploadDir);
    		
    		if (!Files.exists(uploadPath)) {
    			Files.createDirectories(uploadPath);
    		}
    		
    		String fileName = System.currentTimeMillis() + "_" + StringUtils.cleanPath(file.getOriginalFilename());
    		Path filePath = uploadPath.resolve(fileName);
    		Files.copy(file.getInputStream(), filePath);
    		
    		club.setLogo(fileName);
    		club.setOrgLogo(file.getOriginalFilename());
    	}
    }
}

<template>
    <div class="board-detail-container">
      <h4>게시글 상세</h4>
      <hr />
      <div class="board-detail-content">
        <div class="board-title">{{ bstore.board.title }}</div>
        <div class="board-info">
          <span>작성자: {{ cstore.getMemberInfo(lstore.loginUser.userId).name }}</span>
          <span>등록일: {{ bstore.board.date.substring(0, 10) }}</span>
          <span>조회수: {{ bstore.board.viewCnt }}</span>
        </div>
        <div class="board-text">{{ bstore.board.content }}</div>
        <img :src="filePreview" alt="게시글 이미지" v-if="filePreview" class="board-image" />
        <div class="board-actions">
          <button @click="deleteBoard" class="action-button">삭제</button>
          <button @click="updateBoard" class="action-button">수정</button>
          <button @click="goBoardList" class="action-button">목록</button>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import { useBoardStore } from "@/stores/board";
  import { ref, onMounted } from "vue";
  import { useRoute, useRouter } from "vue-router";
  import axios from "axios";
  import { useClubStore } from "@/stores/club";
  import { useLoginStore } from "@/stores/login";
  
  const bstore = useBoardStore();
  const cstore = useClubStore();
  const lstore = useLoginStore();
  const route = useRoute();
  const filePreview = ref(null);
  const router = useRouter();
  
  onMounted(() => {
    bstore.getBoard(route.params.boardId);
    filePreview.value = `http://localhost:8080/resources/${bstore.board.file}`;
  });
  
  const goBoardList = function () {
    router.push({ name: "boardList" });
  };
  
  const deleteBoard = function () {
    axios
      .delete(`http://localhost:8080/api-board/board/${route.params.boardId}`)
      .then(() => {
        router.push({ name: "boardList" });
      });
  };
  
  const updateBoard = function () {
    router.push({ name: "boardUpdate" });
  };
  </script>
  
  <style scoped>
  .board-detail-container {
    max-width: 800px;
    margin: auto;
    background-color: white;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }
  
  h4 {
    text-align: center;
    margin-bottom: 20px;
  }
  
  .board-detail-content {
    padding: 20px;
  }
  
  .board-title {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
  }
  
  .board-info {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    font-size: 14px;
    color: #555;
  }
  
  .board-text {
    margin-bottom: 20px;
    line-height: 1.6;
  }
  
  .board-image {
    max-width: 100%;
    border-radius: 10px;
    margin-bottom: 20px;
  }
  
  .board-actions {
    display: flex;
    justify-content: space-around;
  }
  
  .action-button {
    padding: 10px 20px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }
  
  .action-button:hover {
    background-color: #0056b3;
  }
  </style>
  
<template>
    <div class="board-container">
      <h4>게시글 목록</h4>
      <hr />
      <table class="board-table">
        <thead>
          <tr>
            <th>번호</th>
            <th>제목</th>
            <th>쓰니</th>
            <th>조회수</th>
            <th>등록일</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(board, index) in bstore.boardList" :key="board.boardId">
            <td>{{ index + 1 }}</td>
            <td>
              <RouterLink
                :to="{
                  name: 'boardDetail',
                  params: { clubId: clubId, boardId: board.boardId },
                }"
                class="board-link"
                >{{ board.title }}</RouterLink
              >
            </td>
            <td>{{ cstore.getMemberInfo(lstore.loginUser.userId).name }}</td>
            <td>{{ board.viewCnt }}</td>
            <td>{{ board.date.substring(0, 10) }}</td>
          </tr>
        </tbody>
      </table>
      <div class="actions">
        <RouterLink :to="{ name: 'boardCreate' }" class="create-button">게시글 작성</RouterLink>
      </div>
      <BoardSearchInput />
    </div>
  </template>
  
  <script setup>
  import { useBoardStore } from "@/stores/board";
  import { useClubStore } from "@/stores/club";
  import { onMounted, ref } from "vue";
  import { useRoute } from "vue-router";
  import BoardSearchInput from "./BoardSearchInput.vue";
  import { useLoginStore } from "@/stores/login";
  
  const lstore = useLoginStore();
  const cstore = useClubStore();
  const bstore = useBoardStore();
  const route = useRoute();
  const clubId = ref(route.params.clubId);
  
  onMounted(() => {
    console.log(clubId);
    bstore.getBoardList(clubId);
  });
  </script>
  
  <style scoped>
  .board-container {
    max-width: 1000px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }
  
  h4 {
    text-align: center;
    margin-bottom: 20px;
  }
  
  .board-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
  }
  
  .board-table th, .board-table td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: center;
  }
  
  .board-table th {
    background-color: #f4f4f4;
    font-weight: bold;
  }
  
  .board-table tr:nth-child(even) {
    background-color: #f9f9f9;
  }
  
  .board-table tr:hover {
    background-color: #f1f1f1;
  }
  
  .board-link {
    text-decoration: none;
    color: #007bff;
  }
  
  .board-link:hover {
    text-decoration: underline;
  }
  
  .actions {
    text-align: center;
    margin-top: 20px;
  }
  
  .create-button {
    display: inline-block;
    padding: 10px 20px;
    background-color: #007bff;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
  }
  
  .create-button:hover {
    background-color: #0056b3;
  }
  </style>
  
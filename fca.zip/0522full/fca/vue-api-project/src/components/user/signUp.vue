<template>
  <div class="container mt-5 p-4 shadow rounded bg-white">
    <h2 class="mb-4 text-center">회원가입</h2>
    <form @submit.prevent="updateProfile">
      <div class="form-group mb-3">
        <label for="name">이름:</label>
        <input type="text" class="form-control" id="name" v-model="profile.name" required />
      </div>
      <div class="form-group mb-3">
        <label for="email">이메일:</label>
        <input type="email" class="form-control" id="email" v-model="profile.email" />
      </div>
      <div class="form-group mb-3">
        <label for="password">비밀번호 입력:</label>
        <input type="password" class="form-control" id="password" v-model="newPassword" />
      </div>
      <div class="form-group mb-3">
        <label for="passwordConfirm">비밀번호 확인:</label>
        <input type="password" class="form-control" id="passwordConfirm" v-model="newPasswordConfirm" />
      </div>
      <div class="form-group mb-3">
        <label for="gender">성별:</label>
        <select class="form-control" id="gender" v-model="profile.gender" required>
          <option value="true">Male</option>
          <option value="false">Female</option>
        </select>
      </div>
      <div class="form-group mb-3">
        <label for="birth"> 생년월일:</label>
        <input type="date" class="form-control" id="birth" v-model="profile.birth" required />
      </div>
      <div class="form-group mb-3">
        <label for="intro">자기소개:</label>
        <textarea class="form-control" id="intro" v-model="profile.intro"></textarea>
      </div>
      <div class="form-group mb-3">
        <label for="profile">프로필 사진:</label>
        <input type="file" class="form-control" id="profile" @change="handleProfileUpload" />
        <img :src="profilePreview" alt="Profile Picture" class="img-thumbnail mt-3" v-if="profilePreview" />
      </div>
      <button type="submit" class="btn btn-primary btn-block">회원 가입</button>
      <p v-if="errorMessage" class="text-danger mt-3">{{ errorMessage }}</p>
    </form>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useLoginStore } from "@/stores/login";
import axios from "axios";
import { useRouter } from "vue-router";

const store = useLoginStore();
const profile = ref({ ...store.loginUser });
const accessToken = sessionStorage.getItem('accessToken');
const newPassword = ref("");
const newPasswordConfirm = ref("");
const profilePreview = ref(null);
const errorMessage = ref(null);
const router = useRouter();

const handleProfileUpload = (event) => {
  const file = event.target.files[0];
  if (file) {
    profile.value.profile = file;
    profilePreview.value = URL.createObjectURL(file);
  }
};

const updateProfile = async () => {
  if (newPassword.value && newPassword.value !== newPasswordConfirm.value) {
    errorMessage.value = "비밀번호가 일치하지 않습니다.";
    return;
  }

  const user = {
    userId: profile.value.userId,
    email: profile.value.email,
    name: profile.value.name,
    gender: profile.value.gender,
    birth: profile.value.birth,
    intro: profile.value.intro,
    password: newPassword.value ? newPassword.value : store.loginUser.password
  };

  const formData = new FormData();
  formData.append("user", new Blob([JSON.stringify(user)], { type: "application/json" }));

  if (profile.value.profile instanceof File) {
    formData.append("profile", profile.value.profile);
  }

  try {
    const res = await axios.post(
      `http://localhost:8080/fca/sign-up`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          'accessToken': accessToken,
        },
      }
    );
    alert("회원가입 성공!");
    store.loginUser = { ...profile.value, profile: res.data.profile };
    errorMessage.value = null;
    router.push({name:"home"})
  } catch (error) {
    console.error("회원가입 실패:", error);
    errorMessage.value = "회원가입에 실패했습니다. 다시 시도해주세요.";
  }
};

onMounted(() => {
  profile.value = { ...store.loginUser };
  if (profile.value.profile && !(profile.value.profile instanceof File)) {
    profilePreview.value = `http://localhost:8080/resources/${profile.value.profile}`;
  }
});
</script>

<style scoped>
.container {
  max-width: 600px;
  margin: auto;
}
</style>

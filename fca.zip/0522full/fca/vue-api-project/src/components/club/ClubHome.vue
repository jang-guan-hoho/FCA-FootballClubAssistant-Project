<template>
  <div class="box">
    <section >
      <div class="header">
        <div>현재 인원 : {{ store.clubMember.length }} 명 / {{ store.club.maxMember }} 명</div>
        <button v-if="!isAdmin" class="btn btn-success" type="button" @click="joinClub">가입 신청</button>
        <button v-else class="btn btn-success" type="button" @click="goToClubManage">클럽 관리</button>
      </div>
      <!-- 클럽 관리 버튼 추가 -->
      <div class="members">
        <div class="member" v-for="member in store.clubMember" :key="member.id">
          <img class="member-img" :src="`http://localhost:8080/resources/${member.profile}`" alt="member image" />
          <div class="member-name">{{ member.name }}</div>
          <div class="member-position">{{ member.position }}</div>
          <div class="member-intro">{{ member.intro }}</div>
        </div>
      </div>
    </section>
    <RouterView />
  </div>
</template>

<script setup>
import { useRoute, useRouter } from "vue-router";
import { useClubStore } from "@/stores/club";
import { onMounted, ref, watch } from "vue";
import axios from "axios";
import { useLoginStore } from "@/stores/login";

const store = useClubStore();
const lstore = useLoginStore();
const route = useRoute();
const router = useRouter();
const userId = ref(lstore.loginUser.userId);
const isAdmin = ref(false);
const position = ref(null);

const getPosition = () => {
  const member = store.clubMember.find((member) => member.userId === userId.value);
  if (member) {
    position.value = member.position;
  }
};

const isAdminCheck = () => {
  isAdmin.value = position.value === "클럽장";
};

watch(() => store.clubMember, getPosition);
watch(position, isAdminCheck);

onMounted(() => {
  store.getClub(route.params.clubId).then(() => {
    getPosition();
    isAdminCheck();
  });
});

const joinClub = async () => {
  try {
    const userId = store.loginUser.id; // 로그인된 유저의 ID를 가져오는 방법
    await axios.post(`http://localhost:8080/club/${route.params.clubId}/join`, {
      userId,
    });
    router.push({ name: "clubHome", params: { clubId: route.params.clubId } });
    console.log("클럽 가입 신청");
  } catch (error) {
    console.error("클럽 가입 신청 중 오류 발생:", error);
  }
};



const goToClubManage = () => {
  router.push({
    name: "ClubManageView",
    params: { clubId: route.params.clubId },
  });
};
</script>

<style scoped>

.member-img {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: #ccc;
}
.member-name {
  font-size: 14px;
  font-weight: bold;
}
.header {
  padding-top: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}
.member {
  display: flex;
  align-items: center;
  gap: 10px;
}
.members {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.box {
  max-width: 500px;
  margin: auto;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  padding: 20px;
}
.btn {
  padding: 10px 20px;
  border-radius: 20px;
}
.member-intro{
  position: relative;
  left: 10%;
}
.member-name{
  font-size: 17px;
  font-weight: bold;
}
</style>

<template>
  <div class="body" style="opacity: 1;">

      <div class="date-navigation">
        <button @click="decrementMonth">&lt;</button>
        <span>{{ year }}년 {{ month }}월</span>
        <button @click="incrementMonth">&gt;</button>
      </div>
      <hr /> 
      <div class="summary">
        <div>이월 회비 : {{ store.receiptMap.lastMoney }}원</div>
        <div>이번달 사용액 : {{ store.receiptMap.currentCost }}원</div>
      </div>
      <hr /> 

      <table>
        <tr >
          <th>항목</th>
          <th>금액</th>
        </tr>
      
      <template v-for="dcost in store.receiptMap.dateCost" :key="dcost.date">
        <tr>
        <td> {{ dcost.date }}</td>
         
          
    
          <td>{{ dcost.cost }}</td>
        </tr>
        <template
        v-for="(dreceipt, index) in store.receiptMap.dateReceipt"
        :key="index"
        >

        <table class="detail" v-if="dcost.date === dreceipt.date">
          <tr>
            <th>날짜:{{ dcost.date }}</th>
            <th>세부항목</th>
            <th>금액</th>
          </tr>
          <tr>
            <td></td>
          <td>{{ dreceipt.item }} </td>
          <td> {{ dreceipt.price }}</td>
        </tr>
        </table>
      </template>
    </template>

    <tr>
      <td>월 회비</td>
      <td class="total">{{ store.receiptMap.currentPayment }}원</td>
    </tr>
      </table>
      <div class="balance">
        잔여 회비 : {{ store.receiptMap.currentMoney }}원
      </div>

  </div>
</template>

<script setup>
import { useScheduleStore } from "@/stores/schedule";
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";
const store = useScheduleStore();
const route = useRoute();

const nowDate = new Date();
const year = ref(nowDate.getFullYear());
const month = ref(nowDate.getMonth() + 1);
const newDate = ref("");

function handleDateChange() {
  newDate.value = year.value + "-" + month.value;
  store.getReceiptMap(route.params.clubId, newDate.value);
}

const incrementMonth = () => {
  if (month.value === 12) {
    year.value += 1;
    month.value = 1;
  } else {
    month.value += 1;
  }
  handleDateChange();
};

const decrementMonth = () => {
  if (month.value === 1) {
    year.value -= 1;
    month.value = 12;
  } else {
    month.value -= 1;
  }
  handleDateChange();
};

onMounted(() => {
  newDate.value = year.value + "-" + month.value;
  store.getReceiptMap(route.params.clubId, newDate.value);
});
</script>

<style scoped>
body {
  font-family: Arial, sans-serif;
  background-color: #f5f5f5;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  margin: 0;
}
.container {
  background-color: #ffffff;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  padding: 30px;
  width: 400px;
  text-align: center;
  opacity: 1;
}
.summary {
  display: flex;
  justify-content: space-around;
  margin-bottom: 20px;
  font-weight: bold;
}
.summary div {
  color: #ff0000;
}
.summary div:first-child {
  color: #000000;
}
table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 20px;
}
th,
td {
  padding: 15px;
  font-size: 1.2em;
  text-align: center;
}
th {
  text-align: center;
  font-size: 1.2em;
}
.total {
  font-weight: bold;
  font-size: 1.5em;
  color: #0000ff;
}
.balance {
  font-weight: bold;
  font-size: 1.5em;
  text-align: right;
  margin: 20%;
}
.date-navigation {
  display: flex;
  justify-content: space-around;
  align-items: center;
  margin-bottom: 20px;
  font-size: 1.5em;
}
button {
  font-size: 1.2em;
  padding: 10px 20px;
}
.detail{
  position: relative;
  
  font-size: 15px;
}
</style>

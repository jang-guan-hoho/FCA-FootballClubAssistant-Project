<template>
  <div class="container">
    <h4>장소 생성</h4>
    <KakaoMap />
    <br />
    <form @submit.prevent="createPlace" class="form">
      <fieldset>
        <div class="form-group">
          <label for="placeName">장소 이름:</label>
          <input type="text" id="placeName" v-model="newPlace.name" required>
        </div>
        <div class="form-group">
          <label for="address">주소:</label>
          <input type="text" id="address" v-model="newPlace.address" required>
        </div>
        <div class="form-group">
          <label for="url">URL:</label>
          <input type="text" id="url" v-model="newPlace.url" required>
        </div>
        <button type="submit" class="submit-btn">생성</button>
      </fieldset>
    </form>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import axios from 'axios';
import KakaoMap from '@/components/common/kakao/KakaoMap.vue';

const accessToken = sessionStorage.getItem('accessToken');
const newPlace = ref({
  name: '',
  address: '',
  url: '',
});

const router = useRouter();
const route = useRoute();

const createPlace = async () => {
  try {
    const response = await axios.post(
      `http://localhost:8080/fca/club/${route.params.clubId}/place`,
      newPlace.value,
      { headers: { 'accessToken': accessToken } }
    );
    const placeId = response.data.placeId;
    console.log(response.data);
    console.log('장소 생성 완료, placeId:', placeId);
    // 장소 생성 후 placeId를 가지고 스케줄 생성 페이지로 이동
    router.push({ name: 'ClubScheduleCreate', params: { placeId: placeId, clubId: route.params.clubId } });
  } catch (error) {
    console.error('장소 생성 중 오류 발생:', error);
  }
};
</script>

<style scoped>
.container {
  max-width: 600px;
  margin: auto;
  padding: 20px;
  background-color: #f9f9f9;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h4 {
  text-align: center;
  margin-bottom: 20px;
  color: #333;
}

.form {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

fieldset {
  border: 1px solid #ccc;
  border-radius: 5px;
  padding: 20px;
  background-color: #fff;
}

legend {
  font-size: 1.2em;
  color: black;
  padding: 0 10px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

label {
  font-weight: bold;
  color: #555;
}

input[type="text"] {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 1em;
  box-sizing: border-box;
  margin-bottom: 10px;
}

input[type="text"]:focus {
  border-color: #007bff;
  outline: none;
}

.submit-btn {
  padding: 10px 20px;
  background-color: rgb(25, 209, 71);
  color: #fff;
  border: none;
  border-radius: 5px;
  font-size: 1em;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.submit-btn:hover {
  background-color: #0056b3;
}
</style>

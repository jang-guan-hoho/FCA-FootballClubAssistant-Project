<template>
  <div>
    <a>Club Schedule Detail</a>
    <div v-if="sstore.schedule.scheduleId">
      <div>
        <h3>오늘 일정</h3>
        <KakaoMap />
        <RouterLink :to="{name:'ClubPlaceUpdate', params:{placeId:sstore.schedule.placeId}}">장소 수정</RouterLink>
        <p>시간: {{ sstore.schedule.time }}</p>
        <p>장비: {{ sstore.schedule.equipment }}</p>
        <p>모집인원: {{ sstore.schedule.match }}명</p>
        <p>현재인원: {{ sstore.participant.length }}명</p>
        <RouterLink :to="{name:'ClubScheduleUpdate', params:{scheduleId:sstore.schedule.scheduleId}}">일정 수정</RouterLink>
      </div>
      <div>
        <button v-if="!isUserParticipating" @click="joinSchedule">참여 신청</button>
        <button v-else @click="cancelSchedule">참여 취소</button>
      </div>
      <div v-for="participant in userList" :key="participant.userId">
        <div>{{ participant.profile }}</div>
        <div>{{ participant.name }}</div>
      </div>
      <button @click="deleteSchedule">일정 삭제</button>
    </div>
    <table>
      <tr>
        <th>항목</th>
        <th>금액</th>
      </tr>
      <tr v-for="receipt in receipts" :key="receipt.receiptId">
        <td>{{ receipt.item }}</td>
        <td>{{ receipt.price }}원</td>
        <button @click="deleteReceipt(receipt.receiptId)">삭제</button>
      </tr>
      <tr>
        <td></td>
        <td><h5>Total:{{ totalAmount }}원</h5></td>
      </tr>
    </table>
    <form @submit.prevent="createReceipt">
      <input type="text" v-model="receipt.item">
      <input type="number" v-model="receipt.price">
      <button type="submit">추가</button>
    </form>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, computed } from 'vue';
import { useScheduleStore } from '@/stores/schedule';
import KakaoMap from '@/components/common/kakao/KakaoMap.vue';
import { useRoute, useRouter } from 'vue-router';
import { useClubStore } from '@/stores/club';
import { useLoginStore } from '@/stores/login';
import axios from 'axios';

const accessToken = sessionStorage.getItem('accessToken');
const route = useRoute();
const sstore = useScheduleStore();
const cstore = useClubStore();
const lstore = useLoginStore();
const router = useRouter();

const receipt = ref({
  scheduleId: sstore.schedule.scheduleId,
  item: '',
  price: '',
});
const participantId = ref(null);
const userList = ref([]);
const receipts = ref([]);

const createReceipt = async function() {
  await sstore.createReceipt(route.params.clubId, route.params.scheduleId, receipt.value);
  receipts.value = sstore.receipt
};

const cancelSchedule = async function() {
  try {
    participantId.value = findParticipantId();
    const res = await axios.delete(`http://localhost:8080/fca/club/${route.params.clubId}/schedule/${route.params.scheduleId}/participant/${participantId.value}`, {
      headers: { 'accessToken': accessToken }
    });
    sstore.participant = res.data;
    console.log(sstore.participant);
    await cstore.getUserList(sstore.participant);
    userList.value = cstore.userList;
  } catch (err) {
    console.log(err);
  }
};

function findParticipantId() {
  const loginUser = lstore.loginUser;
  const participant = sstore.participant.find(p => p.userId === loginUser.userId);
  return participant ? participant.participantId : null;
}

const deleteReceipt = async function(receiptId) {
  const res = await axios.delete(`http://localhost:8080/fca/club/${route.params.clubId}/schedule/${route.params.scheduleId}/receipt/${receiptId}`, {
    headers: { 'accessToken': accessToken }
  });
  sstore.receipt = res.data;
  router.push({ name: 'clubScheduleDetail', params: { date: sstore.schedule.date } });
};

async function loadScheduleDetails() {
  try {
    await sstore.getSchedule(route.params.scheduleId);
    console.log("Schedule loaded:", sstore.schedule);

    if (sstore.schedule && sstore.schedule.scheduleId) {
      await sstore.getScheduleDetail(route.params.clubId, route.params.scheduleId);

      console.log(sstore.participant);

      await cstore.getUserList(sstore.participant);
      userList.value = cstore.userList;
    }

    sstore.receipt = [...sstore.receipt];
    
    participantId.value = findParticipantId();
    console.log("participantId: ", participantId.value);
  } catch (error) {
    console.error("Error loading schedule details:", error);
  }
}

onMounted(() => {
  loadScheduleDetails();
});

watch(() => sstore.schedule, (newSchedule) => {
}, { immediate: true });

watch(() => cstore.userList, (newUserList) => {
  userList.value = newUserList;
}, { deep: true });
watch(() => sstore.receipt, (newReceipt) => {
  receipts.value = newReceipt;
  console.log('receipt list updated:', receipts.value);
}, { deep: true });
const joinSchedule = async function() {
  try {
    const res = await axios.post(`http://localhost:8080/fca/club/${route.params.clubId}/schedule/${route.params.scheduleId}/participant`, null, {
      headers: { 'accessToken': accessToken }
    });
    sstore.participant = res.data;
    console.log(sstore.participant);
    await cstore.getUserList(sstore.participant);
    userList.value = cstore.userList;
  } catch (err) {
    console.log(err);
  }
};

const deleteSchedule = async function() {
  try {
    await axios.delete(`http://localhost:8080/api-board/board/${sstore.schedule.scheduleId}`, null, {
      headers: { 'accessToken': accessToken }
    });
    router.push({ name: 'clubScheduleList' });
  } catch (err) {
    console.log(err);
  }
};

const totalAmount = computed(() => {
  return (sstore.receipt || []).reduce((sum, receipt) => sum + receipt.price, 0);
});

const isUserParticipating = computed(() => {
  const loginUser = lstore.loginUser;
  return userList.value.some(participant => participant.userId === loginUser.userId);
});
</script>

<style scoped>
</style>

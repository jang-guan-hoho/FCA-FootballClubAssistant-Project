<template>
    <div class="container">
        <h2 class="text-center">클럽 리스트</h2>
      <div class="row">
        <div class="col-md-6 mb-4" v-for="club in store.clubList" :key="club.clubId">
          <div class="card" style="width: 100%;">
            <img :src="club.profile" class="card-img-top" alt="Club profile image">
            <div class="card-body">
              <h5 class="card-title">{{ club.name }}</h5>
              <p class="card-text">{{ club.content }}</p>
              <RouterLink :to="{ name: 'clubHome', params: { clubId: club.clubId } }">
                <a class="btn btn-success">클럽 홈</a>
              </RouterLink>
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import { useClubStore } from '@/stores/club';
  import { onMounted } from 'vue';
  const store = useClubStore();
  onMounted(() => {
    console.log("ClubList.vue onMounted 훅 실행됨");
    store.getClubList();
  });
  </script>
  
  <style scoped>
  .container {
    margin-top: 20px;
  }
  .card{
    opacity: 0.9;
    text-align: center;
    align-items: center;
  }
  .card-title{
    font-weight: bold;
    font-size: 25px;
  }
  </style>
  
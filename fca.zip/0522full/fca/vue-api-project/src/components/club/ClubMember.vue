<template>
  <div class="container">
    <div class="header">
      <div>{{ store.clubMember.length }} / {{ store.club.maxMember }}</div>
    </div>
    <table>
      <thead>
        <tr>
          <th>프로필</th>
          <th>이름</th>
          <th>직책</th>
          <th>마지막 일정 참가일</th>
          <th>회비 납부 여부</th>
          <th>탈퇴</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="member in clubMember" :key="member.userId">
          <td>
            <img
              :src="`http://localhost:8080/resources/${member.profile}`"
              alt="프로필 이미지"
              class="profile-img"
            />
          </td>
          <td>{{ member.name }}</td>
          <td>
            <select v-model="member.position" @change="updatePosition(member)">
              <option value="클럽원">클럽원</option>
              <option value="클럽장">클럽장</option>
            </select>
          </td>
          <td>{{ member.currentDate }}</td>
          <td v-if="member.currentDate">
            <button :class="isFeePaid(store.getLastPayment(member.userId)?.payDate) ? 'paid' : 'unpaid'">
              {{ isFeePaid(store.getLastPayment(member.userId)?.payDate) ? "납부" : "미납" }}
            </button>
          </td>
          <td>
            <button class="remove-btn" @click="removeMember(member.userId)">탈퇴</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
import { useClubStore } from "@/stores/club";
import { useLoginStore } from "@/stores/login";
import axios from "axios";
import { ref, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";

const store = useClubStore();
const accessToken = sessionStorage.getItem("accessToken");
const clubMember = ref([]);
const route = useRoute();
const router = useRouter();
const lstore = useLoginStore();

onMounted(() => {
  clubMember.value = store.clubMember;
  store.getLastPayment(lstore.loginUser.userId)
});

const updatePosition = (member) => {
  axios
    .put(
      `http://localhost:8080/fca/club/${route.params.clubId}/manage/${member.memberId}`,
      member,
      { headers: { accessToken: accessToken } }
    )
    .then(() => {
      router.push({
        name: "ClubMember",
        params: { clubId: route.params.clubId },
      });
    });
};

const isFeePaid = (payDate) => {
  if (!payDate) return false;
  const [year, month] = payDate.split("-").map(Number);
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth() + 1;
  return year === currentYear && month === currentMonth;
};

const removeMember = (memberId) => {
  axios
    .delete(`http://localhost:8080/fca/club/${route.params.clubId}/manage/${memberId}`,
    { headers: { accessToken: accessToken } })
    .then(() => {
      clubMember.value = clubMember.value.filter(member => member.userId !== memberId);
    });
};
</script>

<style scoped>
.container {
  max-width: 800px;
  margin: auto;
  background-color: white;
  border-radius: 10px;
  padding: 20px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.header {
  display: flex;
  justify-content: flex-end;
  margin-bottom: 10px;
  font-weight: bold;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th, td {
  padding: 10px;
  text-align: center;
  border-bottom: 1px solid #ddd;
}

.profile-img {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: #ccc;
  object-fit: fill;
  object-position: center;
}

.paid {
  background-color: lightgreen;
  border: none;
  border-radius: 5px;
  padding: 5px 10px;
}

.unpaid {
  background-color: lightcoral;
  border: none;
  border-radius: 5px;
  padding: 5px 10px;
}

.remove-btn {
  background-color: red;
  color: white;
  border: none;
  border-radius: 5px;
  padding: 5px 10px;
  cursor: pointer;
}

select {
  padding: 5px;
  border-radius: 5px;
  border: 1px solid #ccc;
}

select:focus {
  outline: none;
  border-color: #007bff;
}

button {
  cursor: pointer;
}
</style>

<template>
<div class="navbar" style="max-width: 540px;">
  <div id="box">
    <div class="box-item">
      <img :src="`http://localhost:8080/resources/${store.club.logo}`" class="img-fluid rounded-start" alt="store.club.clubImg">
    </div>
    <div >
      <div class="box-item">
        <h3>{{ store.club.name }}</h3>
        <h5>{{ store.club.content }}</h5>
        <p><small class="text-body-secondary">{{ store.club.region}}</small></p>
      </div>
    </div>
  </div>
  <div>
  <button class="btn btn-primary" @click="openModal">
  회비 결제
</button>
</div>
</div>
   
    <!-- 모달 구조 -->
    <div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="paymentModalLabel">회비 결제</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <CheckoutView :clubId="store.club.clubId" :clubFee="clubFee" :clubName="store.club.name" />
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">닫기</button>
          </div>
        </div>
      </div>
    </div>

</template>

<script setup>
import { useClubStore } from '@/stores/club';
import { onMounted, ref, watch } from 'vue';
import * as bootstrap from 'bootstrap';
import CheckoutView from '@/views/CheckoutView.vue';

const store = useClubStore();
const clubFee = ref(1000); // 초기 값 설정

const openModal = () => {
  // clubFee 값이 제대로 설정되었는지 확인
  console.log('Opening modal with club fee:', clubFee.value);
  const paymentModal = new bootstrap.Modal(document.getElementById('paymentModal'));
  paymentModal.show();
};

onMounted(() => {
  // clubFee가 업데이트 될 때마다 로그를 출력
  watch(() => store.club.fee, (newFee) => {
    console.log('Updated club fee:', newFee);
    clubFee.value = newFee;
  }, { immediate: true }); // 초기 값 설정을 위해 immediate: true 옵션 사용
});
</script>

<style scoped>
.navbar {
  display: flex;
  justify-content: space-around;
  background-color: white;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  display: flex;
  margin:  auto;
  border-radius: 15px;
  min-width: 1320px; /* 양옆 폭을 줄이기 위해 max-width 설정 */
  opacity : 0.9;
}
.box-item{

  margin: 30px;
}

#box{
  display: flex;
  margin: 10px;
}

.img-fluid{
  width: 100px;
  height: 100px;
}
</style>

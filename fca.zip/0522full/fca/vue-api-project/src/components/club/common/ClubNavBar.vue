<template>
  <div class="navbar">
    <header class="box">
      <nav class="item">
        <RouterLink class="nav-item" :to="{ name: 'clubHome', params: { clubId: clubId } }">홈</RouterLink> |
        <RouterLink class="nav-item" :to="{ name: 'clubScheduleList', params: { clubId: clubId } }">일정</RouterLink> |
        <RouterLink class="nav-item" :to="{ name: 'boardList', params: { clubId: clubId } }">게시판</RouterLink> |
        <RouterLink
          class="nav-item"
          :to="{ name: 'clubScheduleDetailReceipt', params: { clubId: clubId, receiptDate: today } }"
          >월별 회비</RouterLink
        >
      </nav>
    </header>
  </div>
</template>

<script setup>
import { useClubStore } from "@/stores/club";
import { onMounted } from "vue";
import { useRoute } from "vue-router";

const route = useRoute();
const store = useClubStore();

const currentDate = new Date();
const props = defineProps({
  clubId: {
    type: Number,
    required: true,
  },
});

onMounted(() => {
  console.log(props.clubId);
  store.getClub(props.clubId);
});

// 날짜와 시간을 문자열로 포맷팅
const today = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}`;
</script>

<style scoped>
.navbar {
  background-color: white;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  display: flex;
  justify-content: center;
  margin: 0 auto;
  border-radius: 15px;
  max-width: 1320px; /* 양옆 폭을 줄이기 위해 max-width 설정 */
  opacity : 0.8;
}

.box {
  display: flex;
  justify-content: center;
  width: 100%;
}

.item {
  display: flex;
  justify-content: center;
  padding: 10px 0;
  gap: 10px;
}

.nav-item {
  text-decoration: none;
  color: black;
  font-weight: bold;
}

.router-link-exact-active {
  color: red;
}
</style>

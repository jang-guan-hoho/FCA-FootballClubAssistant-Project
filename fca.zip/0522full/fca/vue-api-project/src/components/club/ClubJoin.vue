<template>
  <div>
    <h2>클럽 가입 페이지</h2>
    <div>{{ cstore.club.name }}</div>
    <div>{{ cstore.club.logo }}</div>
    <div>{{ cstore.club.img }}</div>
    <div>{{ cstore.clubMember.length }}/{{ cstore.club.maxMember }}</div>
    <div>{{ cstore.club.fee }}</div>
    <div>{{ cstore.club.content }}</div>

    <table>
      <tr>
        <th>맴버 프로필</th>
        <th>이름</th>
      </tr>
      <tr v-for="member in cstore.clubMember" :key="member.id">
        <th><img :src="member.img" alt="member image" /></th>
        <th>{{ member.name }}</th>
      </tr>
    </table>

    <button type="button" @click="joinClub">가입 신청</button>
  </div>
</template>

<script setup>
import { useClubStore } from "@/stores/club";
import { useLoginStore } from "@/stores/login";
import axios from "axios";
import { onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";

const cstore = useClubStore();
const ustore = useLoginStore();
const route = useRoute();
const router = useRouter();
const accessToken = sessionStorage.getItem("accessToken");
// const userId = ref(1)
// const joinClub = async () => {
//   try {
//     const userId = ustore.loginUser.userId; // 로그인된 유저의 ID를 가져오는 방법
//     await axios.post(
//       `http://localhost:8080/fca/club/${route.params.clubId}/join`,
//       null,
//       {
//         headers: { accessToken: ustore.accessToken },
//       }
//     );
//     cstore.getMyClubList();
//     console.log("라우터 전");
//     router.push({ name: "clubHome", params: { clubId: route.params.clubId } });
//     console.log("클럽 가입 신청");
//   } catch (error) {
//     console.error("클럽 가입 신청 중 오류 발생:", error);
//   }
// };
const joinClub = () => {
  const userId = ustore.loginUser.userId; // 로그인된 유저의 ID를 가져오는 방법
  axios
    .post(`http://localhost:8080/fca/club/${route.params.clubId}/join`, null, {
      headers: { accessToken: accessToken },
    })
    .then(() => {
      cstore.getMyClubList();
      console.log("라우터 전");
      router.push({
        name: "clubHome",
        params: { clubId: route.params.clubId },
      });
      console.log("클럽 가입 신청");
    })
    .catch((error) => {
      console.error("클럽 가입 신청 중 오류 발생:", error);
    });
};
onMounted(() => {
  cstore.getClub(route.params.clubId);
  // store.getClubMember(route.params.clubId);
});
</script>

<style scoped></style>

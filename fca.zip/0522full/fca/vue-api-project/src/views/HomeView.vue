<template>
  <div class="home-container">
    <div class="content">
      <p>
        축구 클럽 관리를 위한 최고의 솔루션,<br />
        FootBall Club Assistant에 오신 것을 환영합니다.<br />
        회원 관리, 일정 계획, 회비 결제 등 모든 것을 손쉽게 관리하세요.<br />
        오늘 가입하고 클럽 운영을 한 단계 더 발전시키세요!
      </p>
      <RouterLink class="btn btn-primary" v-if="accessToken=== null" to="/login"
        >Login</RouterLink>
        <RouterLink class="btn btn-success" v-else :to="{ name: 'clubList' }">클럽 리스트</RouterLink>
    </div>
  </div>
</template>

<script setup>
console.log("HomeView.vue setup 실행됨");
const accessToken = sessionStorage.getItem("accessToken");
</script>

<style scoped>
.home-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh; /* 화면 높이에 맞게 중앙 정렬 */
}

.content {
  text-align: center;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

p {
  font-size: 24px; /* 글씨를 크게 설정 */
  line-height: 1.8; /* 줄 간격을 넓게 설정 */
}
</style>

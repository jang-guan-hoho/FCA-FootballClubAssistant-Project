<template>
    <div>
    <ClubNavBar :clubId="route.params.clubId"/>
    <br/>
    <ClubInfoBar />
    <br/>
</div>
    <div class="container">
        
        <RouterView />
    </div>
</template>

<script setup>
import ClubNavBar from '@/components/club/common/ClubNavBar.vue';
import ClubInfoBar from '@/components/club/common/ClubInfoBar.vue';

import { useClubStore } from '@/stores/club';
import { onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';

const clubStore = useClubStore();
const route = useRoute();
const router = useRouter();

onMounted(async () => {
    // 클럽 목록 불러오기
    await clubStore.getMyClubList();

    let isMyClub = false;
    clubStore.MyClubList.forEach((MyClub) => {
        console.log(MyClub.clubId);
        console.log(route.params.clubId);
        if (MyClub.clubId == route.params.clubId) {
            isMyClub = true;
        }
    });

    if (isMyClub) {
        router.push({
            name: "clubHome",
            params: { clubId: route.params.clubId },
        });
    } else {
        alert("클럽에 가입되어 있지 않습니다.");
        router.push({
            name: "ClubJoin",
            params: { clubId: route.params.clubId },
        });
    }
});
</script>

<style scoped>
.container {
  background-color: white;
  font-family: Arial, sans-serif;
  border-radius: 15px;
  min-height: 1100px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}



.header {
  position: relative;
  text-align: center;
}

.header-image {
  width: 100%;
  height: auto;
}

.navigation {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  display: flex;
  gap: 20px;
  font-size: 18px;
}

.main-content {
  padding: 20px;
}

.club-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background-color: #f9f9f9;
  padding: 20px;
  border-radius: 8px;
}

.club-logo img {
  width: 50px;
  height: 50px;
}

.club-description {
  flex: 1;
  margin-left: 20px;
}

.pay-button {
  background-color: #4caf50;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.member-list {
  margin-top: 20px;
  background-color: #f9f9f9;
  padding: 20px;
  border-radius: 8px;
}

.member-count {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.join-button {
  background-color: #4caf50;
  color: white;
  padding: 5px 10px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.members {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

.member {
  display: flex;
  align-items: center;
  margin-top: 10px;
}

.member-photo {
  width: 40px;
  height: 40px;
  background-color: #ddd;
  border-radius: 50%;
  margin-right: 10px;
}

.member-name {
  font-size: 16px;
}

.router-view-container {
  background-color: white;
  padding: 20px;
  margin-top: 20px;
  border-radius: 15px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}
</style>

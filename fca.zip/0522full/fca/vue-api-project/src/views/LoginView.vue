<template>
  <div class="login-container">
    <div class="login-box">
      <h1>로그인</h1>
      <form @submit.prevent="handleLogin">
        <input type="text" placeholder="Email" v-model="email" class="input-field" />
        <input type="password" placeholder="Password" v-model="password" class="input-field" />
        <button class="login-button">로그인</button>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useLoginStore } from "@/stores/login";

const loginStore = useLoginStore();
const email = ref("");
const password = ref("");

const handleLogin = () => {
  const userInfo = {
    email: email.value,
    password: password.value,
  };

  loginStore.login(userInfo);
};
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;

}

.login-box {
  background-color: white;
  padding: 40px;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  text-align: center;
  width: 300px;
}

h1 {
  margin-bottom: 20px;
  font-size: 24px;
}

.input-field {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border: 1px solid #ddd;
  border-radius: 5px;
}

.login-button {
  width: 100%;
  padding: 10px;
  border: none;
  border-radius: 5px;
  background-color: #42b983;
  color: white;
  font-size: 16px;
  cursor: pointer;
}

.login-button:hover {
  background-color: #36a572;
}
</style>

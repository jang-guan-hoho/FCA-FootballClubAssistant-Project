<template>


  <div class="navbar">
    <header class="box">
      <nav class="item">
        <RouterLink class="nav-item" :to="{ name: 'myClubList' }">마이 클럽</RouterLink> |
    <RouterLink class="nav-item" :to="{ name: 'clubList' }">클럽 리스트</RouterLink>
  </nav>
</header>
</div>
<br />
<RouterView />
</template>

<script setup>
import { useClubStore } from "@/stores/club";
import { onMounted } from "vue";

const store = useClubStore();

onMounted(() => {
  store.getClubList();
  store.getMyClubList();
});
</script>

<style scoped>
.navbar {
  background-color: white;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  display: flex;
  justify-content: center;
  margin: 0 auto;
  border-radius: 15px;
  max-width: 1320px; /* 양옆 폭을 줄이기 위해 max-width 설정 */
  opacity : 0.8;
}

.box {
  display: flex;
  justify-content: center;
  width: 100%;
}

.item {
  display: flex;
  justify-content: center;
  padding: 10px 0;
  gap: 10px;
}

.nav-item {
  text-decoration: none;
  color: black;
  font-weight: bold;
}

.router-link-exact-active {
  color: red;
}</style>

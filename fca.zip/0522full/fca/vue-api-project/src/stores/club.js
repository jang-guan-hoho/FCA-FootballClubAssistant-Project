import { ref } from "vue";
import { defineStore } from "pinia";
import axios from "axios";
import router from "@/router";
import { useLoginStore } from "./login";

const REST_CLUB_API = "http://localhost:8080/fca/club";
const REST_CLUB_MEMBER_API = "http://localhost:8080/fca/clubMember";

const accessToken = sessionStorage.getItem("accessToken");
export const useClubStore = defineStore(
  "club",
  () => {
    const loginStore = useLoginStore();
    const clubList = ref([]);
    const MyClubIdList = ref([]);
    const MyClubList = ref([]);
    const club = ref({});
    const clubMember = ref([
      // 더미 데이터
    ]);

    const paymentList = ref([])
    const createClub = function (club) {
      const formData = new FormData();
      formData.append("name", club.name);
      formData.append("maxMember", club.maxMember);
      formData.append("fee", club.fee);
      formData.append("deadline", club.deadline);
      formData.append("bank", club.bank);
      formData.append("content", club.content);
      formData.append("account", club.account);
      formData.append("region", club.region);
      if (club.clubImg) {
        formData.append("clubImg", club.clubImg);
      }
      if (club.logo) {
        formData.append("logo", club.logo);
      }

      axios({
        url: REST_CLUB_API,
        method: "POST",
        data: formData,
        headers: {
          "Content-Type": "multipart/form-data",
          accessToken: accessToken,
        },
      })
        .then(() => {
          router.push({ name: "clubHome" });
        })
        .catch((err) => {
          console.log(err);
        });
    };

    const getLastPayment = (userId) => {
      const userPayments = paymentList.value.filter(payment => payment.userId === userId);
      return userPayments.length > 0 ? userPayments[userPayments.length - 1] : null;
    };
    const getClubMember = function (clubId) {
      axios
        .get(`${REST_CLUB_API}/${clubId}`, {
          headers: { accessToken: accessToken },
        })
        .then((response) => {
          clubMember.value = response.data;
        });
    };

    const getClub = async function (clubId) {
      console.log(clubId);
      await axios
        .get(`${REST_CLUB_API}/${clubId}`, {
          headers: { accessToken: accessToken },
        })
        .then((response) => {
          console.log(response);
          club.value = response.data.club;
          console.log(club.value);
          clubMember.value = response.data.memberList;
        });
    };

    const updateClub = async function (formData) {
      try {
        const response = await axios.put(
          `${REST_CLUB_API}/${formData.get("clubId")}/manage`,
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
              accessToken: accessToken,
            },
          }
        );
        this.club = response.data;
        return response.data;
      } catch (error) {
        console.error("클럽 업데이트 중 오류 발생:", error);
        throw error;
      }
    };

    const userList = ref([]);
    const getUserList = (participants) => {
      // participant 객체 순회하며 userId 추출
      userList.value = [];
      try {
        const participantIds = participants.map(participant => {
          return participant.userId;
        });
        console.log('Participant IDs:', participantIds);

        participantIds.forEach(userId => {
          const foundUser = clubMember.value.find(user => user.userId === userId);

          if (foundUser) {
            userList.value.push(foundUser);
          } else {
            console.log('No user found with ID:', userId);
          }
        });
      } catch (error) {
        console.error('Error processing participants:', error);
      }
    };


    const getClubList = function () {
      console.log("getClubList 함수 호출됨");
      axios
        .get("http://localhost:8080/fca", {
          headers: { accessToken: accessToken },
        })
        .then((response) => {
          console.log("API 응답 데이터:", response.data);
          clubList.value = response.data;
        })
        .catch((err) => {
          console.log(err);
        });
    };

    const getMyClubList = async function () {
      console.log("getMyClubList 호출됨");
      try {
        const response = await axios.get(`${REST_CLUB_API}/myClub`, {
          headers: { accessToken: accessToken },
        });
        MyClubList.value = response.data;
        console.log("MyClubList 갱신됨:", MyClubList.value);
      } catch (err) {
        console.error("getMyClubList 오류:", err);
      }
    };

    const updateMyClubList = function () {
      MyClubList.value = [];
      MyClubIdList.value.forEach((clubId) => {
        const club = clubList.value.find((c) => c.clubId === clubId);
        if (club) {
          MyClubList.value.push(club);
        }
      });
    };

    const joinClub = function (clubId, user) {
      axios
        .post(`${REST_CLUB_API}/${clubId}/join`, user, {
          headers: { accessToken: loginStore.accessToken },
        })
        .then(() => {
          router.push({ name: "clubHome", params: { clubId: clubId } });
        });
    };
    const getMemberInfo = function (userId) {
      return clubMember.value.find((member) => member.userId === userId);
    };
    const createPayment = function (payment, clubId) {
      console.log(payment);
      console.log(clubId);
      axios
        .post(`${REST_CLUB_API}/${clubId}/payment`, payment, {
          headers: { accessToken: accessToken },
        })
        .then(() => {
          alert("결제 성공");
          router.push({ name: "clubHome", params: { clubId: clubId } });
        });
      alert("결제 성공");
      // router.push({ name: 'clubHome', params: { clubId: clubId } });
    };

    // const isClubIn = function () {
    //   updateMyClubList();
    //   return MyClubList.value && Object.keys(MyClubList.value).length > 0;
    // };

    return {
      getMemberInfo,
      createPayment,
      joinClub,
      createClub,
      clubMember,
      getClubMember,
      club,
      updateClub,
      userList,
      getUserList,
      clubList,
      // isClubIn,
      getClubList,
      MyClubIdList,
      MyClubList,
      getMyClubList,
      updateMyClubList,
      getClub,
      paymentList,
      getLastPayment,
    };
  },
  { persist: true }
);

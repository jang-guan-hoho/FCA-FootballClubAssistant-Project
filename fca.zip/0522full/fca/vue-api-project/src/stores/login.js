import { ref, computed } from "vue";
import { defineStore } from "pinia";
import axios from "axios";
import router from "../router";

export const useLoginStore = defineStore(
  "login",
  () => {
    const loginUser = ref({});

    // SessionStorage에서 토큰 가져오기
    const accessToken = ref("");

    // 로그인 함수
    const login = async (userInfo) => {
      try {
        const res = await axios.post(
          "http://localhost:8080/fca/login",
          userInfo
        );
        console.log(res);
        accessToken.value = res.data.accessToken;
        sessionStorage.setItem("accessToken", res.data.accessToken); // 토큰을 SessionStorage에 저장
        console.log(accessToken.value);

        // 유저 객체를 응답 데이터로 설정
        loginUser.value = {
          userId: res.data.loginUser.userId,
          email: res.data.loginUser.email,
          password: res.data.loginUser.password,
          name: res.data.loginUser.name,
          gender: res.data.loginUser.gender,
          birth: res.data.loginUser.birth,
          intro: res.data.loginUser.intro,
          profile: res.data.loginUser.profile,
        };

        router.replace({ name: "home" });
      } catch (e) {
        console.log("로그인 실패");
        console.log(e);
      }
    };
    // 로그아웃 함수
    const logout = () => {
      accessToken.value = "";
      sessionStorage.removeItem("accessToken"); // SessionStorage에서 토큰 제거
      loginUser.value = {};
      router.replace({ name: "home" });
      alert("로그아웃 성공!")
    };

    // 회원가입 함수
    const signup = async (formData) => {
      try {
        await axios.post("http://localhost:8080/user/signup", formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
        alert("회원가입 성공!");
      } catch (error) {
        console.error("회원가입 실패:", error);
        throw error;
      }
    };

    return { accessToken, loginUser, login, logout, signup };
  },
  { persist: true }
);

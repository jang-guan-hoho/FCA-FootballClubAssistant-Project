<template>
  <TheHeaderNav/>

  <div id="main">
    <RouterView/>
  </div>


</template>

<script setup>
import TheHeaderNav from '@/components/common/TheHeaderNav.vue'

</script>

<style scoped>
/* #main{
  background-image: url('@/assets/img/background.PNG');
} */
</style>

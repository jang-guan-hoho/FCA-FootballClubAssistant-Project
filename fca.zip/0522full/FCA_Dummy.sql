
-- 클럽 데이터 삽입
INSERT INTO club (name, max_member, content, fee, deadline, club_img, logo, account, bank, region, money)
VALUES 
('FC Awesome', 50, 'A great football club', 20000, 10, 'img1.png', 'logo1.png', 12345678, 'Bank A', 'Seoul Gangnam-gu', 50000),
('FC Brilliant', 40, 'The most brilliant club', 15000, 15, 'img2.png', 'logo2.png', 87654321, 'Bank B', 'Busan Haeundae-gu', 30000),
('FC Champion', 30, 'Champion football club', 10000, 5, 'img3.png', 'logo3.png', 11223344, 'Bank C', 'Incheon Namdong-gu', 40000);

-- 유저 데이터 삽입
INSERT INTO user (email, password, name, gender, birth, intro)
VALUES 
('user1@example.com', 'password1', 'Kim Cheolsoo', 1, '1990-01-01', 'Hello, I am Cheolsoo'),
('user2@example.com', 'password2', 'Lee Younghee', 0, '1992-02-02', 'Hi, I am Younghee'),
('user3@example.com', 'password3', 'Park Jimin', 1, '1994-03-03', 'Hey, I am Jimin');

-- 유저 데이터 삽입
-- INSERT INTO user (email, password, name, gender, birth, intro, profile)
-- VALUES 
-- ('user1@example.com', 'password1', 'Kim Cheolsoo', 1, '1990-01-01', 'Hello, I am Cheolsoo', 'profile1.png'),
-- ('user2@example.com', 'password2', 'Lee Younghee', 0, '1992-02-02', 'Hi, I am Younghee', 'profile2.png'),
-- ('user3@example.com', 'password3', 'Park Jimin', 1, '1994-03-03', 'Hey, I am Jimin', 'profile3.png');

-- 장소 데이터 삽입
INSERT INTO place (name, address, url)
VALUES 
('Stadium A', 'Seoul Gangnam-gu 123', 'http://stadiumA.com'),
('Stadium B', 'Busan Haeundae-gu 456', 'http://stadiumB.com'),
('Stadium C', 'Incheon Namdong-gu 789', 'http://stadiumC.com');

-- 스케줄 데이터 삽입
INSERT INTO schedule (title, date, time, `match`, equipment, cost, place_id, club_id)
VALUES 
('Match 1', '2023-05-01', '10:00-12:00', 5, 'Ball, Net', 10000, 1, 1),
('Match 2', '2023-06-10', '14:00-16:00', 7, 'Ball, Net', 20000, 2, 2),
('Match 3', '2023-07-15', '18:00-20:00', 6, 'Ball, Net', 15000, 3, 3);

-- 멤버 데이터 삽입
INSERT INTO member (club_id, user_id, position, `current_date`)
VALUES 
(1, 1, 'Leader', '2023-05-01'),
(2, 2, 'Member', '2023-06-10'),
(3, 3, 'Member', '2023-07-15');


-- 참가자 데이터 삽입
INSERT INTO participant (schedule_id, user_id)
VALUES 
(1, 1),
(2, 2),
(3, 3);

-- 영수증 데이터 삽입
INSERT INTO receipt (item, price, schedule_id)
VALUES 
('Water', 5000, 1),
('Snacks', 10000, 2),
('Drinks', 15000, 3);

-- 결제 데이터 삽입
INSERT INTO payment (payment_id, pay_date, price, comment, club_id, user_id)
VALUES 
('pay_1', '2024-05-01 10:00:00', 50000, 'Monthly fee', 1, 1),
('pay_2', '2024-06-10 10:00:00', 60000, 'Monthly fee', 2, 2),
('pay_3', '2024-07-15 10:00:00', 70000, 'Monthly fee', 3, 3);

-- 게시판 데이터 삽입
INSERT INTO board (title, content, category, date, user_id, club_id, view_cnt, file)
VALUES 
('Notice 1', 'This is the first notice', 'Notice', '2023-05-01', 1, 1, 10, 'file1.png'),
('General 1', 'This is a general post', 'General', '2023-06-10', 2, 2, 20, 'file2.png'),
('Notice 2', 'This is the second notice', 'Notice', '2023-07-15', 3, 3, 30, 'file3.png');
